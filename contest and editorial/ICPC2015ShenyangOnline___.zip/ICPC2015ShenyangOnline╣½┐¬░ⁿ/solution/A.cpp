#include <cstdio>
#include <cstring>
#define MOD 10007
struct Thash{
	int cur, flag[1000007], lab[1000007], value[1000007];
	Thash() {cur = -1; memset(flag, 255, sizeof(flag));}
	void clear() { ++cur; }
	bool find(int k) {
		int p = k % 1000007;
		while (flag[p] == cur && lab[p] != k) p = (p + 1) % 1000007;
		return flag[p] == cur;
	}
	int& operator[](int k) {
		int p = k % 1000007;
		while (flag[p] == cur && lab[p] != k) p = (p + 1) % 1000007;
		if (flag[p] != cur) flag[p] = cur, lab[p] = k, value[p] = 0;
		return value[p];
	}
};
struct Tstack{
	int top, s[100000];
	void clear(){top = 0;}
	bool empty(){return top == 0;}
	void push(int k) { s[++top] = k; }
	int pop() { return s[top--]; }
};
int E[32], D[32];
void init_all() {
	for (int i = 0; i < 32; ++i) {
		D[i] = i * 2;
		E[i] = (3 << D[i]);
	}
}
int n, p, k, a[200];
Thash h[2];
Tstack s[2];
void init() {
	scanf("%d%d%d", &n, &p, &k);
	for (int i = 1; i <= n; ++i) a[i] = 1;
	for (int i = 1; i <= k; ++i) { int t; scanf("%d", &t), a[t] = 0; }
}
int get(int x, int k) { return  (x >> D[k]) & 3; }
int set(int x, int k, int y) { return (x | E[k]) - E[k] + (y << D[k]); }
void updata(int f, int k, int x) { if (!h[f].find(k)) s[f].push(k); h[f][k] = (h[f][k] + x) % MOD; }
void solve() {
	h[0].clear(); h[1].clear(); s[0].clear(); s[1].clear(); updata(0, 0, 1);
	int last = 1, cur = 0, k, kv;
	for (int i = 1; i <= n; ++i) {
		last ^= 1, cur ^= 1, h[cur].clear(), s[cur].clear();
		while (!s[last].empty()) {
			k = s[last].pop(), kv = h[last][k];
			if (a[i] == 0) {
				if (get(k, p + 1) > 0) continue;
				if (get(k, p - 1) > 1) continue;
				updata(cur, k << 2, kv);
			} else {
				if (get(k, p + 1) > 1) continue;
				if (get(k, p + 1) == 1) {
					if (get(k, p - 1) > 0) updata(cur, set(set(k, p + 1, 0), p - 1, get(k, p - 1) - 1) << 2, kv);
					if (get(k, 0) > 0) updata(cur, set(set(k, p + 1, 0), 0, get(k, 0) - 1) << 2, kv);
					updata(cur, (set(k, p + 1, 0) << 2) + 1, kv);
				} else {
					if (get(k, p - 1) > 0) updata(cur, (set(k, p - 1, get(k, p - 1) - 1) << 2) + 1, kv);
					if (get(k, 0) > 0) updata(cur, (set(k, 0, get(k, 0) - 1) << 2) + 1, kv);
					if (get(k, p - 1) > 0 && get(k, 0) > 0) updata(cur, set(set(k, p - 1, get(k, p - 1) - 1), 0, get(k, 0) - 1) << 2, kv);
					updata(cur, (k << 2) + 2, kv);
				}
			}
		}
	}
	printf("%d\n", h[cur][0]);
}
int main() {
    //freopen("A.in","r",stdin); freopen("A.out","w",stdout);
	init_all(); int tt; scanf("%d", &tt);
	for ( int i=1;i<=tt;i++) {
        init(); printf("Case #%d: ",i); solve();
    }
}
