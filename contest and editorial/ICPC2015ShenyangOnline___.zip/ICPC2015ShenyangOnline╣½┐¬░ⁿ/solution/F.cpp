# include <cstdio>
# include <cstring>

# define REP(i, n) for (int i = 1; i <= n; i ++)

const int NR = 1001000;
char s[NR];
int q0;
int main ()
{
	//freopen ("F.in", "r", stdin);
	//freopen ("F.out", "w", stdout); 
	scanf ("%d", &q0);
	REP (id, q0)
	{
		scanf ("%s", s + 1);
		printf ("Case #%d: ", id);
		int len = strlen (s + 1), p = -1; bool oth = 0;
		REP (i, len)
		{
			if (s[i] == 'c') p = i;
			else if (s[i] != 'f') {oth = 1; break;}
		}
		if (oth) {puts ("-1"); continue;}
		if (p == -1) {printf ("%d\n", (len + 1) >> 1); continue;}
		int i = p, c = 2, ans = 0; bool suc = 1;
		do
		{
			if (s[i] == 'c') 
			{
				if (c >= 2) c = 0, ans ++;
				else {suc = 0; break;}
			}
			else c ++;
			i ++;
			if (i > len) i = 1;
		} while (i != p);
		if (c < 2 || !suc) {puts ("-1"); continue;}
		printf ("%d\n", ans);
	}
	return 0;
}

