#include <ctime>
#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std ;

const int MAXN =  20009 ;
const int MAXQ = 200009 ;

int F[MAXN] ;
int find(int x) { return F[x] = ( F[x] == x ? x : find(F[x]) ) ; }
void bing( int u , int v ) {
    int t1 = find(u) , t2 = find(v) ;
    if ( t1 != t2 ) F[t1] = t2 ;
}

bool vis[MAXN] ;
int ancestor[MAXN] ;
struct Edge { int to , next ; } edge[MAXN*2] ;
int head[MAXN] , tot ;
void addedge(int u,int v) { edge[tot].to = v; edge[tot].next = head[u]; head[u] = tot++; }

struct Query { int q , next , index; } query[MAXQ*2] ;
int answer[MAXQ] ;
int h[MAXQ] ;
int n , tt , Q ;
void add_query( int u , int v , int index ) {
    query[tt].q = v ; query[tt].next = h[u] ; query[tt].index = index ; h[u] = tt ++ ;
    query[tt].q = u ; query[tt].next = h[v] ; query[tt].index = index ; h[v] = tt ++ ;
}

int UppW[MAXN] ;

bool flag[MAXN] ;
void Init() {
    scanf( "%d%d" , &n , &Q ) ; Q -= (n-1) ;
    tot = 0 ;
    memset( head , -1 , sizeof(head) ) ;
    tt = 0 ;
    memset( h , -1 , sizeof(h) ) ;
    memset( vis , false , sizeof(vis) ) ;
    for ( int i = 1 ; i <= n ; i ++ ) F[i] = i ;
    memset( ancestor , 0 , sizeof(ancestor) ) ;
    memset( flag , false , sizeof(flag) ) ;
    for ( int i = 1 ; i <= n ; i ++ ) UppW[i] = 0 ;
    for ( int i = 1 ; i < n ; i ++ ) {
        int u , v ; scanf( "%d%d" , &u , &v ) ;
        flag[v] = true ; addedge(u , v) ; addedge(v , u) ;
    }
    for ( int i = 0 ; i < Q ; i ++ ) {
        int u , v ; scanf( "%d%d" , &u , &v ) ;
        add_query(u , v , i) ; UppW[u] ++ ; UppW[v] ++ ;
    }
}

void LCA( int u ) {
    ancestor[u] = u ; vis[u] = true ;
    for ( int i = head[u] ; i != -1 ; i = edge[i].next ) {
        int v = edge[i].to ;
        if ( vis[v] ) continue ;
        LCA(v) ; bing(u , v) ; ancestor[find(u)] = u ;
    }
    for ( int i = h[u] ; i != -1 ; i = query[i].next ) {
        int v = query[i].q ;
        if ( vis[v] ) answer[query[i].index] = ancestor[find(v)] ;
    }
}

int Answer ;
void DFS( int fa , int x ) {
    for ( int i = head[x] ; i != -1 ; i = edge[i].next ) if ( edge[i].to != fa ) {
        DFS(x , edge[i].to) ;
        UppW[x] += UppW[edge[i].to] ;
    }
    if ( x != 1 )
        if ( UppW[x] < Answer )
            Answer = UppW[x] ;
}

int main() {
    //freopen("C.in" , "r" , stdin) ;
    //freopen("C.out", "w" ,stdout) ;
    
	clock_t start,end;
	start=clock();
    int test ; scanf("%d" , &test) ;
    for ( int _ = 1 ; _ <= test ; _ ++ ) {
        Init() ;
        LCA(1) ;
        // for ( int i = 0 ; i < Q ; i ++ ) printf( "answer[%d] = %d\n" , i+1 , answer[i] ) ;
        for ( int i = 0 ; i < Q ; i ++ ) UppW[answer[i]] -= 2 ;
        
        Answer = Q + n - 1 ;
        DFS(0 , 1) ;
        printf( "Case #%d: %d\n" , _ , Answer + 1 ) ;
    }
	end=clock();
	//cout<<(double)(end-start)/CLOCKS_PER_SEC<<endl;
}
