#include<bits/stdc++.h>
#define rep(i,s,t) for (i=(s); i<=(t); ++i)
#define dep(i,t,s) for (i=(t); i>=(s); --i)
#define sz(x) ll((x).size())
#define p(i) (1LL<<((i)-1))
#define w(x,i) ((x)&p(i))
#define fi first
#define se second
#define pb push_back
#define pp pop_back
#define dll "%lld"

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef pair<ll,ll> PII;

template<class T> inline T pr(T x) { return --x; }
template<class T> inline T nx(T x) { return ++x; }
template<class T> inline T sqr(T x) { return x*x; }

template<class T>
inline void get(T &n) {
	char c = getchar();
	while (c!='-' && (c<'0' || c>'9')) c = getchar();
	n = 0; T s = 1; if (c=='-') s = -1,c = getchar();
	while (c>='0' && c<='9') n*=10,n+=c-'0',c=getchar();
	n *= s;
}

const int maxn = 260,maxm = 510;
#define inf int(~0U>>3)

//Dinic
const int maxv = 16*maxn+maxn,maxe = 2*(maxv);
struct edge {
	int t,c; edge *nx,*op;
}*V[maxv],*P[maxv],*Lae[maxv],E[maxe];
int EN;

inline void addedge(int a,int b,int c,int d) {
	edge *x = E+(++EN),*y = E+(++EN);
	x->nx = V[a]; V[a] = x; V[a]->t = b; V[a]->c = c;
	y->nx = V[b]; V[b] = y; V[b]->t = a; V[b]->c = d;
	V[a]->op = V[b]; V[b]->op = V[a];
}

int Maxflow,lv[maxv],VS,S,T,Lav[maxv];

bool Dinic_label() {
	int head,tail,u,v; edge* e;
	memset(lv+1,0,sizeof(int)*VS); lv[S] = 1;
	Lav[head=tail=1] = S;
	while (head<=tail) {
		u = Lav[head++];
		for (e=V[u];e;e=e->nx)
			if (e->c && !lv[v=e->t]) {
				lv[v] = lv[u]+1;
				Lav[++tail] = v;
				if (v==T) return true;
			}
	}
	return false;
}

void Dinic_aug() {
	int i,f,u,v,stop; edge* e;
	memmove(P+1,V+1,sizeof(edge*)*VS);
	Lav[stop=1] = S;
	while (stop) {
		u = Lav[stop];
		if (u == T) {
			f = inf;
			for (i=2;i<=stop;i++)
				if (Lae[i]->c < f) f = Lae[i]->c;
			Maxflow += f;
			for (i=stop;i>=2;i--) {
				Lae[i]->c -= f; Lae[i]->op->c += f;
				if (!Lae[i]->c) stop = i-1;
			}
		}
		else {
			for (e=P[u];e;e=e->nx)
				if (e->c && lv[v=e->t]==lv[u]+1) break;
			P[u] = e;
			if (e) Lav[++stop] = v,Lae[stop] = e;
			else lv[u] = 0,stop--;
		}
	}
}

void Dinic() {
	Maxflow = 0;
	while (Dinic_label()) Dinic_aug();
}

char a[maxn][10];//b[maxm][10];

int n,m;
int c0[maxv][2],s0,i0[maxv],cst0[maxv];
int c1[maxv][2],s1,i1[maxv],cst1[maxv];
int Test,Ti;

int main() {
//    freopen("H.in" , "r" , stdin) ;
//    freopen("H.out", "w" ,stdout) ;
    
	clock_t start,end;
	start=clock();
    ll i,j,k,t,tt,x,y,z; string cmd;
    get(Test);
    rep(Ti,1,Test) {
        memset(a,0,sizeof(a));
        memset(c0,0,sizeof(c0)); memset(c1,0,sizeof(c1));
        memset(i0,0,sizeof(i0)); memset(i1,0,sizeof(i1));
        memset(cst0,255,sizeof(cst0)); memset(cst1,255,sizeof(cst1));
        s0 = s1 = 1;
        get(n); get(m);
        rep(k,1,n) {
            for (i=0,get(t); t; t/=2) a[k][++i] = t%2;
            reverse(a[k]+1,a[k]+9);
        }
        rep(k,1,n) {
            x = 1;
            rep(i,1,8) {
                t = a[k][i];
                if (!c0[x][t]) c0[x][t] = ++s0;
                x = c0[x][t];
            }
            i0[x] = k;
        }
        rep(k,1,n) {
            x = 1;
            dep(i,8,1) {
                t = a[k][i];
                if (!c1[x][t]) c1[x][t] = ++s1;
                x = c1[x][t];
            }
            i1[x] = k;
        }
        //int Maxflow,lv[maxv],VS,S,T,Lav[maxv];
        rep(k,1,m) {
            cin>>cmd;
            if (cmd[0]=='P') {
                cin>>cmd; get(tt); x = 1;
                for (char c:cmd) x = c0[x][c-'0'];
                if (cst0[x]==-1 || tt<cst0[x]) cst0[x] = tt;
            }
            else {
                cin>>cmd; get(tt); x = 1;
                reverse(cmd.begin(),cmd.end());
                for (char c:cmd) x = c1[x][c-'0'];
                if (cst1[x]==-1 || tt<cst1[x]) cst1[x] = tt;
            }
        }
        VS = s0+s1+n; S = n+1; T = n+s0+1;
        EN = 0; memset(V,0,sizeof(V));
        rep(x,1,s0) {
            rep(t,0,1) if (y=c0[x][t]) {
                tt = cst0[y]==-1? inf : cst0[y];
                y = i0[y] ? i0[y] : n+y;
                addedge(n+x,y,tt,0);
            }
        }
        rep(x,1,s1) {
            rep(t,0,1) if (y=c1[x][t]) {
                tt = cst1[y]==-1? inf : cst1[y];
                y = i1[y] ? i1[y] : s0+n+y;
                addedge(y,s0+n+x,tt,0);
            }
        }
        Dinic();
        if (Maxflow>=inf) Maxflow = -1;
        printf("Case #%d: %d\n",Ti,Maxflow);
    }

	end=clock();
	//cout<<(double)(end-start)/CLOCKS_PER_SEC<<endl;
    return 0;
}
