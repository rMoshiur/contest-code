#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std ;

typedef long long LL ;

const int MATCH[10] = { 6 , 2 , 5 , 5 , 4 , 5 , 6 , 3 , 7 , 6 } ;

const int MAXN = 503 ;

LL MOD ;
LL N , F[MAXN][2][2][2][MAXN] ;

void Refresh( int i , int bA , int bB , int c , int j , LL kk ) {
    if ( j <= N ) F[i][bA][bB][c][j] = (F[i][bA][bB][c][j] + kk) % MOD ;
}

LL Solve() {
    for ( int i = 0 ; i <= N ; i ++ )
        for ( int bA = 0 ; bA <= 1 ; bA ++ )
            for ( int bB = 0 ; bB <= 1 ; bB ++ )
                for ( int c = 0 ; c <= 1 ; c ++ )
                    for ( int j = 0 ; j <= N ; j ++ )
                        F[i][bA][bB][c][j] = 0 ;
    F[0][1][1][0][0] = 1 ;
    
    LL Ans = 0 ;
    for ( int i = 0 ; i < N/4 ; i ++ )
        for ( int j = 0 ; j <= N ; j ++ )
            for ( int b = 1 ; b <= 3 ; b ++ ) {
                int bA = b % 2 ;
                int bB = b / 2 ;
                for ( int c = 0 ; c <= 1 ; c ++ ) if ( F[i][bA][bB][c][j] != 0 ) {
                    for ( int aa = 0 ; aa <= (bA == 1 ? 9 : 0) ; aa ++ )
                        for ( int bb = 0 ; bb <= (bB == 1 ? 9 : 0) ; bb ++ ) {
                            int costa = ( bA == 1 ? MATCH[aa] : 0 ) ;
                            int costb = ( bB == 1 ? MATCH[bb] : 0 ) ;
                            if ( j + costa + costb + MATCH[(c + aa + bb)%10] <= N ) {
                                Refresh( i+1 , bA , bB , (c + aa + bb)/10 , j + costa + costb + MATCH[(c + aa + bb)%10] , F[i][bA][bB][c][j] ) ;
                                if ( j + costa + costb + MATCH[(c + aa + bb)%10] + 2 * ((c + aa + bb)/10) == N && (bA == 0 || aa != 0) && (bB == 0 || bb != 0) ) {
                                    Ans = (Ans + F[i][bA][bB][c][j]) % MOD ;
//                                    cout << i << "," << bA << "," << bB << "," << c << "," << j << ";" << aa << "," << bb << "::" << Ans << "\n" ;
                                }
                            }
                            if ( bA == 1 && aa != 0 && 
                                 j + costa + costb + MATCH[(c + aa + bb)%10] <= N ) {
                                Refresh( i+1 , 0 , bB , (c + aa + bb)/10 , j + costa + costb + MATCH[(c + aa + bb)%10] , F[i][bA][bB][c][j] ) ;
                            }
                            if ( bB == 1 && bb != 0 &&
                                 j + costa + costb + MATCH[(c + aa + bb)%10] <= N ) {
                                Refresh( i+1 , bA , 0 , (c + aa + bb)/10 , j + costa + costb + MATCH[(c + aa + bb)%10] , F[i][bA][bB][c][j] ) ;
                            }
                        }
                }
            }
    return Ans ;
}

LL Count(int x) {
    if ( x == 0 ) return 0 ;
    else return MATCH[x%10] + Count(x / 10) ;
}

LL Solve2() {
    LL Upp = 0 , Ans = 0 ;
    for ( int i = 1 ; i <= N / 4 ; i ++ ) Upp = Upp * 10 + 1LL ;
    
    for ( int b = 1 ; b <= Upp ; b ++ ) {
        LL cb = Count(b) ;
        if ( cb > N ) continue ;
        for ( int c = 1 ; c <= Upp ; c ++ ) {
            int a = b + c ;
            if ( Count(a) + cb + Count(c) == N ) {
                Ans = (Ans + 1) % MOD ;
            }
        }
    }
    return Ans ;
}

int main() {
//    freopen("small.in" , "r" , stdin) ; freopen("small.out", "w" ,stdout) ;
//    freopen("medium.in" , "r" , stdin) ; freopen("medium.out", "w" ,stdout) ;
//    freopen("large.in" , "r" , stdin) ; freopen("large.out", "w" ,stdout) ;
//    freopen("G.in" , "r" , stdin) ; freopen("G.out", "w" ,stdout) ;
    int Test ; cin >> Test ;
    for ( int i = 1 ; i <= Test ; i ++ ) {
        cin >> N >> MOD ;
        N -= 3 ;
        cout << "Case #" << i << ": " << Solve() << "\n" ;
        // cout << "Brute Force - Case #" << i << ": " << Solve2() << "\n" ;
    }
}
