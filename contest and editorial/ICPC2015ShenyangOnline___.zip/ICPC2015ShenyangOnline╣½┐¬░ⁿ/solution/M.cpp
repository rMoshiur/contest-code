#include<cstdio>
#include<cstring>
#include<algorithm>
#include<vector>
#define maxN (105)
#define maxM (2005)
#define SQR(x) ((x)*(x))
using namespace std;

int N,M,T;

struct Tnode{
	double x,y;
};
struct Tcouple{
	double sigmaX,sigmaY,sigmaX2,sigmaY2;
}couple[maxN];

Tnode intersect(double a1,double b1,double c1,Tnode p1,Tnode p2){
	double a2,b2,c2;
	a2=p2.y-p1.y;
	b2=p1.x-p2.x;
	c2=a2*p1.x+b2*p1.y;
	double det=a1*b2-a2*b1;
	if (!det){
		puts("error!");
		while (true);
	}	
	Tnode ans;
	ans.x=(b2*c1-b1*c2)/det;
	ans.y=(a1*c2-a2*c1)/det;
	return ans;
}
struct Tconvex{
	vector<Tnode> p;
	Tconvex(){
		p.clear();
	}
	void linecut(double a,double b,double c){
		vector<Tnode> tmp;	
		tmp.clear();
		int n=p.size();
		for (int i=0;i<n;i++)
			tmp.push_back(p[i]);
		p.clear();
		for (int i=0;i<n;i++){
			Tnode now,pre;
			now=tmp[i];
			if (i==0)
				pre=tmp[n-1];
			else
				pre=tmp[i-1];
			double s1=a*pre.x+b*pre.y-c;
			double s2=a*now.x+b*now.y-c;
			if (s1*s2<0){
				Tnode ip=intersect(a,b,c,pre,now);
				p.push_back(ip);
			}
			if (s2<=0){
				p.push_back(now);
			}
		}
	}
	void addp(double x,double y){
		Tnode tmp;
		tmp.x=x;
		tmp.y=y;
		p.push_back(tmp);
	}
	double getarea(){
		double ans=0;
		if (p.size()==0)
			return ans;
		p.push_back(p[0]);
		for (int i=1;i<p.size();i++){
			double x1,y1,x2,y2;
			x1=p[i-1].x;
			y1=p[i-1].y;
			x2=p[i].x;
			y2=p[i].y;
			ans+=x1*y2-x2*y1;
		}
		ans/=2;
		return ans;
	}
};
int main(){
	scanf("%d",&T);
	for (int testcase=1;T--;testcase++){
		printf("Case #%d:",testcase);
		scanf("%d%d",&N,&M);
		for (int i=0;i<N;i++){
			double sigmaX,sigmaY,sigmaX2,sigmaY2;
			sigmaX=sigmaY=sigmaX2=sigmaY2=0;
			for (int j=0;j<M;j++){
				int px,py;
				scanf("%d%d",&px,&py);
				sigmaX+=px;
				sigmaY+=py;
				sigmaX2+=SQR(px);
				sigmaY2+=SQR(py);
			}
			couple[i].sigmaX=sigmaX;
			couple[i].sigmaY=sigmaY;
			couple[i].sigmaX2=sigmaX2;
			couple[i].sigmaY2=sigmaY2;
		}
		for (int i=0;i<N;i++){
			Tconvex convex;
			convex.addp(0,0);
			convex.addp(4095,0);
			convex.addp(4095,4095);
			convex.addp(0,4095);
			for (int j=0;j<N;j++){
				if (i==j) continue;
				convex.linecut(2*(couple[j].sigmaX-couple[i].sigmaX),2*(couple[j].sigmaY-couple[i].sigmaY),couple[j].sigmaX2-couple[i].sigmaX2+couple[j].sigmaY2-couple[i].sigmaY2);
			}
			printf(" %.0lf",convex.getarea());
		}
		puts("");
	}
	return 0;
}
