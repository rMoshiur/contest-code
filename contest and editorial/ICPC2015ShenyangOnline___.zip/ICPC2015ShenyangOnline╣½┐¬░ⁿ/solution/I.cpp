#include<bits/stdc++.h>
#define rep(i,s,t) for (i=(s); i<=(t); ++i)
#define dep(i,t,s) for (i=(t); i>=(s); --i)
#define sz(x) ll((x).size())
#define p(i) (1LL<<((i)-1))
#define w(x,i) ((x)&p(i))
#define fi first
#define se second
#define pb push_back
#define pp pop_back
#define dll "%lld"

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef pair<ll,ll> PII;

template<class T> inline T pr(T x) { return --x; }
template<class T> inline T nx(T x) { return ++x; }
template<class T> inline T sqr(T x) { return x*x; }

template<class T>
inline void get(T &n) {
	char c = getchar();
	while (c!='-' && (c<'0' || c>'9')) c = getchar();
	n = 0; T s = 1; if (c=='-') s = -1,c = getchar();
	while (c>='0' && c<='9') n*=10,n+=c-'0',c=getchar();
	n *= s;
}

const int maxn = 30010,maxm = 2*100010;
int n,m,q,p[maxn],fa[maxn],pa[maxn];
int cmd[maxm],a[maxm],b[maxm],ans[maxm];
int S[maxn],T[maxn],dep[maxn],dn;
int dfn[maxn],low[maxn],bel[maxn];
unordered_map<int,int> eg;
unordered_map<int,int> lca;
vector<int> qry[maxn],adj[maxn];
#define PI(i,j) ((i)*maxn+(j))

struct edge {
	int j; bool b,v; edge *op,*nx;
	inline edge():b(0),v(0) {}
}e[maxm],*v[maxn],*par[maxn];
int en;

inline void add_e(int i,int j) {
    e[++en].nx = v[i]; v[i] = e+en; v[i]->j = j;
    e[++en].nx = v[j]; v[j] = e+en; v[j]->j = i;
    v[i]->b = v[i]->v = v[j]->b = v[j]->v = 0;
    v[i]->op = v[j]; v[j]->op = v[i];
}

int getf(int x) { return x==fa[x]?x:(fa[x]=getf(fa[x])); }
int getp(int x) { return x==pa[x]?x:(pa[x]=getp(pa[x])); }

void tarjan0(int i,int p) {
    for (int j:qry[i]) {
        lca[PI(i,j)] = lca[PI(j,i)] = getp(j);
    }
    for (int j:adj[i]) if (j!=p) {
        tarjan0(j,i);
        pa[j] = i;
    }
}

void tarjan1(int i) {
	dfn[i] = low[i] = ++dn;
	for (edge *e=v[i]; e; e=e->nx) {
		if (!e->v) {
			e->v = e->op->v = true;
			int j = e->j;
			if (!dfn[j]) {
				tarjan1(j); par[j] = e;
				low[i] = min(low[i],low[j]);
			} else low[i] = min(low[i],dfn[j]);
		}
    }
}

void dfs(ll i,ll d) {
	S[i] = ++dn; dep[dn] = d;
    for (int j:adj[i])
        if (j!=p[i]) p[j]=i,dfs(j,d+1);
	T[i] = dn;
}

struct vt {
	ll k,mk;
}vt[maxn*4];
ll ql,qr,qk,L,R;

void build(ll x,ll l,ll r) {
	vt[x].k = dep[l]; vt[x].mk = 0;
	if (l==r) return;
	ll mid = (l+r)>>1;
	build(x*2,l,mid); build(x*2+1,mid+1,r);
}

#define mk(x,l,r,dt) { vt[x].mk += (dt); vt[x].k += (dt)*((r)-(l)+1); }

void push(ll x,ll l,ll r) {
	if (!vt[x].mk) return;
	ll mid = (l+r)>>1;
	mk(x*2,l,mid,vt[x].mk); mk(x*2+1,mid+1,r,vt[x].mk);
	vt[x].mk = 0;
}

#define ADD(l,r,k) ql = (l),qr = (r),qk = (k),add(1,L,R)
void add(ll x,ll l,ll r) {
	if (ql<=l && r<=qr) { mk(x,l,r,qk); return; }
	push(x,l,r);
	ll mid = (l+r)>>1;
	if (ql<=mid) add(x*2,l,mid);
	if (qr>mid) add(x*2+1,mid+1,r);
}

#define VAL(l) ( ql = (l),val(1,L,R) )
ll val(ll x,ll l,ll r) {
    if (l==r) return vt[x].k;
	push(x,l,r);
	ll mid = (l+r)>>1;
    return ql<=mid ? val(x*2,l,mid) : val(x*2+1,mid+1,r);
}

void part(int i,int n) {
    int j;
    bel[i] = n;
    for (edge *e=v[i]; e; e=e->nx)
        if (!e->b && !bel[j=e->j])
            part(j,n);
        else if (e->b && bel[j=e->j])
            adj[n].pb(bel[j]),adj[bel[j]].pb(n);//printf("%d %d\n",n,bel[j]);
}

int main() {
    ll i,j,k,t,tt,di,dj,dk,dt;
    ll Test,Ti;
    //freopen("I.in","r",stdin);
    //freopen("I.out","w",stdout);
    get(Test);
    rep(Ti,1,Test) {
        get(n); get(m); get(q);
        eg.clear(); lca.clear();
        en = 0; memset(v,0,sizeof(v));
        memset(bel,0,sizeof(bel));
        memset(dfn,0,sizeof(dfn));
        rep(i,1,n) adj[i].clear(),qry[i].clear();
        rep(k,1,m) {
            get(i); get(j);
            if (i>j) swap(i,j);
            if (i!=j) ++eg[PI(i,j)];
        }
        rep(k,1,q) {
            get(t); get(i); get(j);
            if (i>j) swap(i,j);
            if (t==1 && i!=j) --eg[PI(i,j)];
            cmd[k] = t; a[k] = i; b[k] = j;
        }
        for (auto x:eg) rep(i,1,x.se)
            add_e(x.fi/maxn,x.fi%maxn);

        dn = 0; tarjan1(1);
        rep(i,2,n)
            if (dfn[ par[i]->op->j ] < low[i])
                par[i]->b = par[i]->op->b = true;
        t = n; n = 0;
        rep(i,1,t) if (!bel[i]) part(i,++n);

        rep(i,1,n) pa[i] = fa[i] = i;
        rep(k,1,q) {
            i = a[k] = bel[a[k]]; j = b[k] = bel[b[k]];
            qry[i].pb(j),qry[j].pb(i);
        }
        tarjan0(1,0);

        dn = 0; p[1] = 0; dfs(1,1);
        L = 1; R = n; build(1,L,R);
        dep(k,q,1) {
            i = getf(a[k]); j = getf(b[k]);
            di = VAL(S[i]); dj = VAL(S[j]);
            t = lca[PI(a[k],b[k])]; dt = VAL(S[t]);
            if (cmd[k]==1) {
                for (; di!=dt; --di,i=getf(p[i]))
                    ADD(S[i],T[i],-1),fa[i] = p[i];
                for (; dj!=dt; --dj,j=getf(p[j]))
                    ADD(S[j],T[j],-1),fa[j] = p[j];
            }
            else ans[k] = di-dt + dj-dt;
        }
        printf("Case #%d:\n",Ti);
        rep(k,1,q) if (cmd[k]==2)
            printf("%d\n",ans[k]);
    }

    return 0;
}
