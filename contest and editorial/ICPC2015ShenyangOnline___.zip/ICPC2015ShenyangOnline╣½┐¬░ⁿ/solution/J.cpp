#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std ;

typedef long long LL ;

const int MAXN = 201315 ;
const int MOD  = 530600414 ;

int N ;

LL F[MAXN] , Mid[MAXN] , Left[MAXN] , Right[MAXN] , Count[MAXN] ;

void Initial() {
    Mid[2] = 0 ; Right[2] = 0 ; Left[2] = 0 ; Count[2] = 0 ; F[2] = 2 ;
    Mid[3] = 0 ; Right[3] = 2 ; Left[3] = 1 ; Count[3] = 1 ; F[3] = 3 ;
    
    for ( int i = 4 ; i <= N ; i ++ ) {
        F[i] = F[i-1] + F[i-2] ;
        Mid[i] = Mid[i-2] + Mid[i-1] + Right[i-2] * Count[i-1] + Count[i-2] * Left[i-1] ;
        Right[i] = Right[i-1] + Right[i-2] + Count[i-2] * F[i-1] ;
        Left[i] = Left[i-1] + Left[i-2] + Count[i-1] * F[i-2] ;
        Count[i] = Count[i-1] + Count[i-2] ;
        
        F[i] %= MOD ;
        Left[i] %= MOD ;
        Mid[i] %= MOD ;
        Right[i] %= MOD ;
        Count[i] %= MOD ;
    }
}

LL Solve() {
    return Mid[N] ;
}

int main() {
//    freopen("J.in" , "r" , stdin) ;
//    freopen("J.out", "w" ,stdout) ;
    
    N = 201314 ;
    Initial() ;
    
    int Test ; scanf("%d" , &Test) ;
    for ( int i = 1 ; i <= Test ; i ++ ) {
        scanf("%d" , &N) ;
        printf("Case #%d: %I64d\n" , i , Solve()) ;
    }
}
