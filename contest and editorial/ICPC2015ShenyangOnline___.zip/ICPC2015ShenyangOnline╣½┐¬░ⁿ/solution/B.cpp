#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;

const int MAXN = 3;
long long MOD ;

struct Matrix{
	int n,m; //n lines and m columns
	long long mat[MAXN][MAXN];
	Matrix() {
		memset(mat, 0, sizeof(mat));
		n = m = MAXN;
	}
};
//needs confirm a.m==b.n
Matrix operator *(Matrix a, Matrix b) {
	Matrix c;
	c = Matrix();
	c.n = a.n;
	c.m = b.m;
	for (int i=1;i<=a.n;i++) 
		for (int j=1;j<=b.m;j++)
			for (int k=1;k<=a.m;k++) {
				c.mat[i][j] += (a.mat[i][k]*b.mat[k][j])%MOD;
				c.mat[i][j] %= MOD;
			}
	return c;
}                                   
//needs confirm (a.n==b.n)&&(a.m==b.m)
Matrix operator +(Matrix a, Matrix b) {
	Matrix c;
	c = Matrix();
	c.n = a.n;
	c.m = a.m;
	for (int i=1;i<=a.n;i++)
		for (int j=1;j<=a.m;j++) {
			c.mat[i][j] = (a.mat[i][j]+b.mat[i][j])%MOD;
			c.mat[i][j] = (c.mat[i][j]+MOD)%MOD;
		}
	return c;
}
//needs confirm (a.n==a.m)
Matrix operator ^(Matrix a, long long k) {
	Matrix c;
	int i,j;
	c = Matrix();
    c.n = a.n;
	c.m = a.n;
	for (int i=1;i<=a.n;i++) c.mat[i][i] = 1; //unit Matrix I
	while (k) {
		if (k&1) {
			c = c*a;
		}
		a = a*a;
		k>>=1;
	}
	return c;
}
long long pow2(long long x) {
    if ( x == 0 ) return 1LL ;
    if ( x == 1 ) return 2LL ;
    if ( x % 2 == 0 ) {
        long long tmp = pow2(x/2) ;
        return tmp * tmp ;
    } else {
        return 2LL * pow2(x-1) ;
    }
}
long long SQR(long long x , long long mm) {
    long long ret = 0LL , x0 = x , t = x ;
    while ( t > 0 ) {
        if ( t % 2 == 1 ) ret = (ret + x0) % mm ;
        x0 = (x0 * 2) % mm ;
        t /= 2 ;
    }
    return ret ;
}
long long pow2(long long x , long long mm) {
    if ( x == 0 ) return 1LL ;
    if ( x == 1 ) return 2LL ;
    if ( x % 2 == 0 ) {
        long long tmp = pow2(x/2 , mm) ;
        return SQR(tmp , mm) ;
    } else {
        return (2LL * pow2(x-1 , mm)) % mm ;
    }
}
int main() {
    freopen("B.in","r",stdin); freopen("B.out","w",stdout);
    //freopen("in.txt","r",stdin); freopen("out.txt","w",stdout);
	int T;
	Matrix a,b,c;
	long long k;
	a.n = 2;
	a.m = 2;
	b.n = 2;
	b.m = 2;
    a.mat[1][1]=10; a.mat[1][2]=-1; a.mat[2][1]=1;a.mat[2][2]=0;
	b.mat[1][1]=10; b.mat[1][2]=0; b.mat[2][1]=2; b.mat[2][2]=0;
	cin>>T;
	for ( int _ = 1 ; _ <= T ; _ ++ ) {
		cin>>k>>MOD;
		//k = pow2( k ) ; // Brute Force
        //k = pow2( k , MOD-1 ) ; // Fermat's little theorem
        k = pow2( k , (MOD*MOD-1)*(MOD*MOD-MOD) ) ; // Standard method
        c = ( a ^ (k) ) * b ;
        cout << "Case #" << _ << ": " << (c.mat[1][1]-1+MOD) % MOD << endl ;
	}
	//fclose(stdin);
	//fclose(stdout);
}
