# include <cstdio>
# include <cassert>
# include <algorithm>

using namespace std; 
# define REP(i, n) for (int i = 1; i <= n; i ++)
const int inf = 1 << 30;
typedef pair <int, int> pii;
typedef long long ll;
# define mp make_pair
# define v1 first
# define v2 second

int n, A, B, q0;

inline ll F (ll x, ll y)
{
	return A * x * x + B * y;
}

int main ()
{
//	freopen ("L.in", "r", stdin);
//	freopen ("L.out", "w", stdout);
	scanf ("%d", &q0);
	REP (id, q0)
	{
		scanf ("%d%d%d", &n, &A, &B);
		pii maxw0 = mp (-inf, 0), maxw1 = mp (-inf, 0), minw0 = mp (inf, 0), minw1 = mp (inf, 0), tinw0 = mp (inf, 0), tinw1 = mp (-inf, 0), larw0 = mp (0, 0), larw1 = mp (0, 0);
		int ta;
		REP (i, n)
		{
			scanf ("%d", &ta);
			if (ta > maxw0.v1) maxw1 = maxw0, maxw0 = mp (ta, i);
			else if (ta > maxw1.v1) maxw1 = mp (ta, i);
			
			if (ta < minw0.v1) minw1 = minw0, minw0 = mp (ta, i);
			else if (ta < minw1.v1) minw1 = mp (ta, i);
			
			if (abs (ta) < abs (tinw0.v1)) tinw1 = tinw0, tinw0 = mp (ta, i);
			else if (abs (ta) < abs (tinw1.v1)) tinw1 = mp (ta, i);
			
			if (abs (ta) >= abs (larw0.v1)) larw1 = larw0, larw0 = mp (ta, i);
			else if (abs (ta) >= abs (larw1.v1)) larw1 = mp (ta, i);
		}

		ll ans;

		if (!A) 
			ans = (B >= 0 ? F (0, maxw0.v1) : F (0, minw0.v1));
		else if (!B) 
			ans = (A >= 0 ? F (larw0.v1, 0) : F (tinw0.v1, 0)); 
		else if (A > 0 && B > 0)
		{
			if (larw0 != maxw0) ans = F (larw0.v1, maxw0.v1);
			else ans = max (F (larw0.v1, maxw1.v1), F (larw1.v1, maxw0.v1));
		}
		else if (A > 0 && B < 0)
		{
			if (larw0 != minw0) ans = F (larw0.v1, minw0.v1);
			else ans = max (F (larw0.v1, minw1.v1), F (larw1.v1, minw0.v1));
		}
		else if (A < 0 && B > 0)
		{
			if (tinw0 != maxw0) ans = F (tinw0.v1, maxw0.v1);
			else ans = max (F (tinw0.v1, maxw1.v1), F (tinw1.v1, maxw0.v1));
		}
		else if (A < 0 && B < 0)
		{
			if (tinw0 != minw0) ans = F (tinw0.v1, minw0.v1);
			else ans = max (F (tinw0.v1, minw1.v1), F (tinw1.v1, minw0.v1));
		}
		else assert (0);
		printf ("Case #%d: %I64d\n", id, ans);
	}
	return 0;
}

