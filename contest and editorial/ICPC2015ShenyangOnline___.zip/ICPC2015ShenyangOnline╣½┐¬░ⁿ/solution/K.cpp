#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<ctime>
#include<unordered_map>
#include<algorithm>
using namespace std;

const int MAXN = 8;

int n, q, LIM;
int a[MAXN];
unordered_map<int, long long> f[1<<MAXN];

int lowbit(int x){ return x & -x;}

int cnt(int x)
{
   int t = 0;
   while (x != 0) {x -= lowbit(x); ++t;}
   return t;
}

void init()
{
   scanf("%d %d", &n, &q);
   for (int i = 0; i < n; ++i) scanf("%d", a+i);
   sort(a,a+n);
   LIM = max(2,q);
   for (int i = 0; i < (n+1)/2; ++i) LIM *= max(2,a[n-1-i]);
}

void solve()
{
   for (int i = 1; i < (1 << n); ++i)
      f[i].clear();
   for (int i = 0; i < n; ++i)
      f[1<<i][a[i]] = 1;
   for (int k = 1; k < (1 << n); ++k)
   for (int j = 1; j < k; ++j)
   if ((k & j) == j && k - j < j)
   {
      int i = k - j;
      for (auto ii:f[i])
      for (auto jj:f[j])
      {
         if ( ii.first + jj.first <= LIM && ii.first + jj.first >= 0 ) f[k][ii.first + jj.first] += 2 * ii.second * jj.second;
         
         if ( ii.first - jj.first <= LIM && ii.first - jj.first >= 0 ) f[k][ii.first - jj.first] += ii.second * jj.second;
         if ( jj.first - ii.first <= LIM && jj.first - ii.first >= 0 ) f[k][jj.first - ii.first] += ii.second * jj.second;
         
         if ( ii.first * jj.first <= LIM && ii.first * jj.first >= 0 ) f[k][ii.first * jj.first] += 2LL * ii.second * jj.second;
         
         if (jj.first != 0 && ii.first % jj.first == 0) f[k][ii.first / jj.first] += ii.second * jj.second;
         if (ii.first != 0 && jj.first % ii.first == 0) f[k][jj.first / ii.first] += ii.second * jj.second;
      }
   }
   long long ans = 0;
   for (int i = 1; i < (1 << n); ++i)
   {
	//printf("%d: %d\n", i, f[i][q]);
      ans += f[i][q] * cnt(i) * cnt(i);
   }
   printf("%I64d\n", ans);
}

int main()
{
   //clock_t start,finish; double totaltime; start=clock();
   int tt;
   scanf("%d", &tt);
   for ( int t = 1 ; t <= tt ; t ++ ) {
      init();
      printf("Case #%d: ", t);
      solve();
   }
   //finish=clock(); totaltime=(double)(finish-start)/CLOCKS_PER_SEC;
   //printf("Use Time:%f\n",(double)totaltime);
   return 0;
}

