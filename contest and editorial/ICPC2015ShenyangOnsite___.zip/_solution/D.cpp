#include <iostream>
#include <cstdio>
#include <cstring>
#include <ctime>
using namespace std ;

int n , a , b ;

int gcd( int u , int v ) {
    if ( v == 0 ) return u ;
    return gcd(v , u%v) ;
}

int main() {
    freopen("D.in" , "r" , stdin) ;
    freopen("D.out", "w" ,stdout) ;
    int Test ; cin >> Test ;
    for ( int i = 1 ; i <= Test ; i ++ ) {
        cin >> n >> a >> b ;
        cout << "Case #" << i << ": " << ((n / gcd(a,b)) % 2 == 0 ? "Iaka\n" : "Yuwgna\n" ) ;
    }
	fprintf(stderr,"%.2f s\n",clock()*1.0/CLOCKS_PER_SEC);
	for (;;) ;
}
