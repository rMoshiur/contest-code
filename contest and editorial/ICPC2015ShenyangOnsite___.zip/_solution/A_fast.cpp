#include<bits/stdc++.h>
using namespace std;
#define FZ(i,n) for(int i=0;i<(n);i++)
#define FV(i,st,ed) for(int i=(st);i<(ed);i++)
#define SZ(x) ((int)x.size())
#define ALL(x) (x).begin(),(x).end()

#define RI(x) scanf("%d",&(x))
#define RII(x,y) scanf("%d %d",&(x),&(y))

#define FIR first
#define SEC second
#define pritnf printf
#define N 400514
typedef long long int lnt;
typedef double dou;
typedef pair<lnt,lnt> P;
const int mod=1000000007ll;
const int xxx=233ll;
typedef pair<int,int> hel;
hel merge(hel a,hel b){
	return hel( (1ll*a.FIR*b.SEC+b.FIR)%mod,1ll*a.SEC*b.SEC%mod );
}
hel ppp(hel a,lnt x){
	hel ans(0,1);
	for(;x;x/=2){
		if(x&1)ans=merge(ans,a);
		a=merge(a,a);
	}
	return ans;
}
//////////////////
typedef struct ele{
	vector<hel>ph;
	hel sh;
	lnt rt;//repeat times
	lnt tN;
	lnt sN;
	string SS;
	ele(){ph.clear();rt=tN=0;}
	ele(char a){
		SS="";
		SS+=a;
		ph.push_back(hel(a,xxx));
		rt=1;
		sN=tN=1;
	}
	ele(const char*s,int n,lnt rt_){
		SS="";
		ph.resize(n);
		hel b(0,1);
		FZ(i,n){
			b=merge(b,hel(s[i],xxx));
			ph[i]=b;
			SS+=s[i];
		}
		rt=rt_;
		sN=tN=rt_*n;
	}
}ele;
bool cmp(ele a,ele b){
	return a.sN<b.sN;
}
inline hel get_hh(ele*hh,int hn,lnt r){
	ele t;t.sN=r;
	int i=upper_bound(hh,hh+hn,t,cmp)-hh;
	lnt lN=SZ(hh[i].ph);
	r-=hh[i].sN-hh[i].tN;
	hel res=merge(ppp(hh[i].ph.back(),r/lN), hh[i].ph[r%lN]);
	return i?merge(hh[i-1].sh,res):res;
}
inline int get_hash(ele*hh,int hn,lnt l,lnt r){
	lnt NN=hh[hn-1].sN;
	hel R=r<NN?get_hh(hh,hn,r):merge(hh[hn-1].sh,get_hh(hh,hn,r-NN));
	hel L=l?merge(get_hh(hh,hn,l-1),ppp(hel(0,xxx),r-l+1)):hel(0,1);
	return R.FIR>=L.FIR?R.FIR-L.FIR:R.FIR+mod-L.FIR;
}
void make_ca(ele*hh,int hn,vector<int>&ca,char mn){
	ca.clear();
	lnt NN=hh[hn-1].sN;
	FZ(i,hn){
		lnt st=hh[i].sN-hh[i].tN;
		int lN=SZ(hh[i].ph);
		FZ(j,lN)if(hh[i].SS[j]==mn)ca.push_back(get_hash(hh,hn,st+j,st+j+NN-1));
		if(hh[i].rt==1)continue;
		st=hh[i].sN-hh[i].tN+(hh[i].rt-1)*lN;
		FZ(j,lN)if(hh[i].SS[j]==mn)ca.push_back(get_hash(hh,hn,st+j,st+j+NN-1));
	}
}
int make_hash(ele*hh,const char*s){
	int m=0;
	for(int i=0;s[i];){
		if(s[i]=='('){
			int j=i++;
			for(;s[j]&&s[j]!=')';j++);
			int k=j+1;
			lnt rt=0;
			for(;'0'<=s[k]&&s[k]<='9';k++){
				rt=rt*10+s[k]-'0';
			}
			if(rt)hh[m++]=ele(s+i,j-i,rt);
			i=k;
		}
		else{
			int j=i;
			for(;'a'<=s[j]&&s[j]<='z';j++);
			hh[m++]=ele(s+i,j-i,1);
			i=j;
		}
	}
	FZ(i,m)if(i)hh[i].sN+=hh[i-1].sN;
	FZ(i,m)hh[i].sh=merge(i?hh[i-1].sh:hel(0,1), ppp(hh[i].ph.back(),hh[i].rt) );
	return m;
}
//////////////////////////////////////
ele sp[N*3];
ele*oh=sp+1,*h1=sp+N+2,*h2=sp+2*N+3;
int ohn,h1n,h2n;
vector<int>ca1  ,ca2;
char os[N],s1[N],s2[N];
int sol(int uuu){
	scanf("%s",os);
	ohn=make_hash(oh,os);
	/////////////////////////////////
	int Q;RI(Q);
	int ans=0;
	FZ(qi,Q){
		scanf("%s",s1);
		int n=0;for(;s1[n];n++);
		h1n=make_hash(h1,s1);
		lnt NN=h1[h1n-1].sN;
		if(NN>oh[ohn-1].sN)continue;
		////////////////////////
		int m=0;
		int flag=0;
		char stk[30];int top;
		FZ(i,ohn){
			if(oh[i].sN<NN){
				s2[m++]='(';
				FZ(j,SZ(oh[i].SS))s2[m++]=oh[i].SS[j];
				s2[m++]=')';
				//////////
				top=0;
				for(int tmp=oh[i].rt;tmp;tmp/=10){
					stk[top++]=tmp%10+'0';
				}
				for(;top;)s2[m++]=stk[--top];
			}
			else{
				lnt r=NN-(oh[i].sN-oh[i].tN);
				lnt lN=SZ(oh[i].ph);
				lnt aa=r/lN,bb=r%lN;
				if(aa){
					s2[m++]='(';
					FZ(j,SZ(oh[i].SS))s2[m++]=oh[i].SS[j];
					s2[m++]=')';
					top=0;
					for(int tmp=aa;tmp;tmp/=10){
						stk[top++]=tmp%10+'0';
					}
					for(;top;)s2[m++]=stk[--top];	
				}
				if(bb){
					FZ(j,bb)s2[m++]=oh[i].SS[j];
				}
				flag=1;break;
			}
		}
		s2[m]=0;
		int cnt[256];
		FV(i,'a','z'+1)cnt[i]=0;
		FZ(i,m)cnt[s2[i]]++;
		char mn='z';
		FV(i,'a','z'+1)if(cnt[i]){mn=i;break;}
		//puts(s2);
		h2n=make_hash(h2,s2);
		make_ca(h2,h2n,ca2,mn);
		make_ca(h1,h1n,ca1,mn);
		////////////////
		sort(ALL(ca1));
		sort(ALL(ca2));
		{	
			int j=0;
			FZ(i,SZ(ca1)){
				for(;j<SZ(ca2)&&ca2[j]<ca1[i];j++);
				if(j==SZ(ca2))break;
				if(ca1[i]==ca2[j]){
					ans+=flag*(qi+1)*(qi+1);
					break;
				}
			}
		}
	}
	pritnf("Case #%d: %d\n",uuu,ans);
	return 1;
}
/*
2
z(rz)3r(rui)2cumt
5
(zr)4
zrzrrui
zr(zr)2z(r)2u
(rz)3
(zr)2z(r)2zr
(ab)2aab(aba)3(ba)2(zhang)940712
4
(babaa)2(baa)2
(aabab)2
(ab)3
(aba)2(ab)3a(ab)2(a)2b
*/
int main(){
	freopen("A.in","r",stdin);
//	freopen("myout.txt","w",stdout);
	int t;
	assert(RI(t)!=EOF);
	for(int ti=1;ti<=t;ti++)sol(ti);
	assert(scanf("%*s")==EOF);
	fprintf(stderr,"%.2f s\n",clock()*1.0/CLOCKS_PER_SEC);
	for(;;);
	return 0;
}

