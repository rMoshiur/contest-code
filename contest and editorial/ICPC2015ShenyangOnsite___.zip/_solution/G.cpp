#include<bits/stdc++.h>
# define eps 1e-8
using namespace std;

typedef long long int64;
void setIO(string name){
	string	is=name+".in",
			os=name+".out";
	freopen(is.c_str(),"r",stdin);
	//freopen(os.c_str(),"w",stdout);
}

int cmp(double a1,double a2){
	if(a1-a2>eps)	return 1;
	if(a2-a1>eps)	return -1;
	return 0;
}

double t,v1,v2;
void work(){
	scanf("%lf %lf %lf",&t,&v1,&v2);
	assert(0<=t&&t<=2000);
	assert(0<=v1&&v1<=2000);
	assert(0<=v2&&v2<=2000);
	if(cmp(v2/v1,3.0)>=0){
		printf("No\n");
	}else if(cmp(v2/v1,sqrt(2))>=0){
		double a=v1*v1/(v2*v2)-1;
		double b=4*v1*v1/(v2*v2)+2;
		double c=4*v1*v1/(v2*v2)-2;

		double x=(-b+sqrt(b*b-4*a*c))/(2*a);
	//	cout<<(2+x)/sqrt((1-x)*(1-x)+1)<<endl;
		int p1=1,p2=2;
		if(cmp(300*(1-x)/v2+t,300*(sqrt(x*x+1)+2)/v1)>=0)	p1++;
		else	p2++;
		if(cmp(300*(2-x)/v2+t,300*(sqrt(x*x+1)+3)/v1)>=0)	p1++;
		else	p2++;

		if(p1>=p2){
			printf("Yes\n");
		}else{
			printf("No\n");
		}
	}else if(cmp(v2/v1,1.0)>=0){
		double tmp=v2*v2/v1/v1;
		double a=tmp-1;
		double b=-2;
		double c=tmp-1;
		double x=(-b-sqrt((b*b-4*a*c)))/(2*a);
		int p1=1,p2=1;
		if(cmp(300*(1-x)/v2+t,300*(x+1)/v1)>=0)	p1++;
		else p2++;
		if(cmp(300*(2-x)/v2+t,300*(x+2)/v1)>=0)	p1++;
		else p2++;
		if(cmp(300*(3-x)/v2+t,300*(x+3)/v1)>=0)	p1++;
		else p2++;
		if(p1>=p2){
			printf("Yes\n");
		}else{
			printf("No\n");
		}	
	}else{
		printf("Yes\n");
	}
}

int main(){
//	setIO("g");
    freopen("G.in" , "r" , stdin) ;
    freopen("G.out", "w" ,stdout) ;
    
	int t;scanf("%d",&t);
	for (int i=1;i<=t;i++) {
        printf("Case #%d: ",i) ;
        work();
    }
	fprintf(stderr,"%.2f s\n",clock()*1.0/CLOCKS_PER_SEC);
	return 0;
}

