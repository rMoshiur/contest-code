#include<cstdio>
#include<cstring>
#include<vector>
#include<ctime>
#define i first
#define j second
#define rep(i,s,t) for (ll i=(s); i<=(t); ++i)
#define pb push_back

using namespace std;

typedef int ll;
typedef pair<ll,ll> PII;

template<class T>
inline void get(T &n) {
	char c = getchar();
	while (c!='-' && (c<'0' || c>'9')) c = getchar();
	n = 0; T s = 1; if (c=='-') s = -1,c = getchar();
	while (c>='0' && c<='9') n*=10,n+=c-'0',c=getchar();
	n *= s;
}

const ll maxn = 20010,maxm = 2*100010;
ll n,m,ans;
ll cut[maxn],g[maxn],sz[maxn],deg[maxn];
ll rk[maxn],fa[maxn],st[maxn],cnt;
vector<ll> u[maxn];
vector<PII> e[maxn];

const ll maxlt = maxn*4; // size
#define O 0 //***** mk's default value
#define Z m //***** ret's initial value
struct LineTree {
    struct vt {
        ll k; ll mk;
    }v[maxlt];
    ll ql,qr,qk,L,R;

    inline void mk(ll x,ll l,ll r,ll dt) {
        v[x].k += dt; //op
        v[x].mk += dt; //op delta
    }
    inline void upd(ll x,ll l,ll r) {
        ll mid = (l+r)>>1;
        v[x].k = min(v[x*2].k,v[x*2+1].k); //op
    }
    void push(ll x,ll l,ll r) {
        if (v[x].mk==O) return;
        ll mid = (l+r)>>1;
        mk(x*2,l,mid,v[x].mk); mk(x*2+1,mid+1,r,v[x].mk);
        v[x].mk = O;
    }
    void build(ll x,ll l,ll r) {
        v[x].k = g[l]; //***** initial value
        v[x].mk = O; //***** initial mk
        if (l==r) return; ll mid = (l+r)>>1;
        build(x*2,l,mid); build(x*2+1,mid+1,r);
        upd(x,l,r);
    }
    void add(ll x,ll l,ll r) {
        if (ql<=l && r<=qr) { mk(x,l,r,qk); return; }
        push(x,l,r);
        ll mid = (l+r)>>1;
        if (ql<=mid) add(x*2,l,mid);
        if (qr>mid) add(x*2+1,mid+1,r);
        upd(x,l,r);
    }
    ll get(ll x,ll l,ll r) {
        if (ql<=l && r<=qr) return v[x].k;
        push(x,l,r);
        ll mid = (l+r)>>1; ll ret = Z; //ret initial value
        if (ql<=mid) ret = get(x*2,l,mid);
        if (qr>mid) ret = min(ret,get(x*2+1,mid+1,r)); //***** op
        return ret;
    }
    inline void INIT(ll l,ll r) { L=l,R=r,build(1,l,r); }
    inline void ADD(ll l,ll r,ll k) { ql=l,qr=r,qk=k,add(1,L,R); }
    inline ll GET(ll l,ll r) { return l>r ? Z : (ql=l,qr=r,get(1,L,R)); } //**** default value
}lt;

#define foru() for (ll j:u[i]) if (j!=p)
#define fore() for (PII x:e[i])
void sigma(ll i,ll p) {
    foru() {
        sigma(j,i);
        sz[i] += sz[j]; cut[i] += cut[j];
    }
}

void part(ll i,ll p,ll pa) {
    ll k = 0;
    g[ rk[i] = cnt++ ] = cut[i];
    st[i] = pa; fa[i] = p;
    foru() if (!k || sz[j]>sz[k]) k = j;
    if (i==1) k = 0;
    if (k) part(k,i,pa);
    foru() if (j!=k) part(j,i,j);
}

void fix(ll i,ll t) {
    for (; i!=1; i=fa[st[i]]) {
        lt.ADD(rk[st[i]],rk[i],t);
    }
}

void add(ll i,ll p) {
    fore() fix(x.i,x.j);
    foru() add(j,i);
}

void del(ll i,ll p) {
    fore() fix(x.i,-x.j);
    foru() del(j,i);
}

void sol(ll i,ll p) {
    ll k = 0,tmp;
    foru() if (!k || sz[j]>sz[k]) k = j;
    foru() if (j!=k) sol(j,i),del(j,i);
    if (k) sol(k,i);
    foru() if (j!=k) add(j,i);
    if (p) {
        fore() fix(x.i,x.j);
        fix(i,-2*cut[i]);
        tmp = min(lt.GET(1,rk[i]-1),lt.GET(rk[i]+1,n-1));
        fix(i,2*cut[i]);
        tmp += cut[i];
        ans = min(ans,tmp);
    }
}

int main() {
    freopen("C.in" , "r" , stdin) ;
    freopen("C.out", "w" ,stdout) ;
    ll i,j,k,t,tt,Test;
    get(Test);
    rep(Ti,1,Test) {
        get(n); get(m);
        rep(i,1,n) {
            deg[i] = 0;
            cut[i] = 0; sz[i] = 1;
            u[i].clear(); e[i].clear();
        }
        rep(k,1,n-1) {
            get(i); get(j);
            ++deg[i]; ++deg[j];
            u[i].pb(j); u[j].pb(i);
        }
        rep(k,n,m) {
            get(i); get(j);
            ++deg[i]; ++deg[j];
            ++cut[i]; ++cut[j];
            e[i].pb({j,-2}); e[j].pb({i,-2});
        }
        ll Min = m;
        rep(i,1,n) Min = min(Min,deg[i]);
        sigma(1,0);
        cnt = 0; part(1,0,1);
        lt.INIT(1,n-1);
        ans = m; sol(1,0);
        printf("Case #%d: %d %d\n",Ti,ans+2,Min);
    }
	fprintf(stderr,"%.2f s\n",clock()*1.0/CLOCKS_PER_SEC);
	for (;;);
    return 0;
}
