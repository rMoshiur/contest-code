#include<bits/stdc++.h>
#define rep(i,s,t) for (ll i=(s); i<=(t); ++i)
#define dep(i,t,s) for (ll i=(t); i>=(s); --i)
#define i first
#define j second
#define pb push_back
#define qb pop_back
#define pf push_front
#define qf pop_front
#define sz(x) ll((x).size())
#define p(i) (1LL<<((i)-1))
#define w(x,i) ((x)&p(i))

using namespace std;

template<class T> inline T pr(T x) { return --x; }
template<class T> inline T nx(T x) { return ++x; }
template<class T> inline T sqr(T x) { return x*x; }

template<class T>
inline void get(T &n) {
	char c = getchar();
	while (c!='-' && (c<'0' || c>'9')) c = getchar();
	n = 0; T s = 1; if (c=='-') s = -1,c = getchar();
	while (c>='0' && c<='9') n*=10,n+=c-'0',c=getchar();
	n *= s;
}

typedef long long ll;
typedef pair<ll,ll> PII;

const ll maxn = 20010,maxm = 20010;
const double pi = 2*acos(0);
ll n,m,cnt;
map<PII,ll> id;
bool vis[maxn];

ll V,bel[maxn],p[maxn],w[maxn];
map<PII,ll> C;

struct graph {
    static const ll maxv = 20100,maxe = 20010;
    ll S,T,VS,ES,Maxflow,lv[maxv],Lav[maxv];
    struct edge {
        ll t,c; edge *nx,*op;
    }E[maxe],*V[maxv],*P[maxv],*Lae[maxv];
    inline void init(ll s,ll t,ll vs) {
        S = s; T = t; VS = vs;
        ES = 0; memset(V+1,0,sizeof(edge*)*VS);
        for (auto x:C) {
            addedge(x.i.i,x.i.j,x.j,x.j);
        }
    }
    inline void addedge(ll a,ll b,ll c,ll d) {
        edge *x = E+(++ES),*y = E+(++ES);
        x->nx = V[a]; V[a] = x; x->t = b; x->c = c;
        y->nx = V[b]; V[b] = y; y->t = a; y->c = d;
        x->op = y; y->op = x;
    }
    bool Dinic_label() {
        ll head,tail,u,v; edge* e;
        memset(lv+1,0,sizeof(ll)*VS); lv[S] = 1;
        Lav[head=tail=1] = S;
        while (head<=tail) {
            u = Lav[head++];
            for (e=V[u];e;e=e->nx)
                if (e->c && !lv[v=e->t]) {
                    lv[v] = lv[u]+1;
                    Lav[++tail] = v;
                    if (v==T) return true;
                }
        }
        return false;
    }
    void Dinic_aug() {
        ll i,f,u,v,stop; edge* e;
        memmove(P+1,V+1,sizeof(edge*)*VS);
        Lav[stop=1] = S;
        while (stop) {
            u = Lav[stop];
            if (u == T) {
                f = ll(~0u>>2);
                for (i=2;i<=stop;i++)
                    if (Lae[i]->c < f) f = Lae[i]->c;
                Maxflow += f;
                for (i=stop;i>=2;i--) {
                    Lae[i]->c -= f; Lae[i]->op->c += f;
                    if (!Lae[i]->c) stop = i-1;
                }
            }
            else {
                for (e=P[u];e;e=e->nx)
                    if (e->c && lv[v=e->t]==lv[u]+1) break;
                P[u] = e;
                if (e) Lav[++stop] = v,Lae[stop] = e;
                else lv[u] = 0,stop--;
            }
        }
    }
    void part(ll i) {
        bel[i] = 1;
        for (edge *e=V[i]; e; e=e->nx)
            if (e->c && !bel[e->t]) part(e->t);
    }
    ll Dinic() {
        Maxflow = 0;
        while (Dinic_label()) Dinic_aug();
        memset(bel+1,0,sizeof(ll)*VS);
        part(S);
        return Maxflow;
    }
}G;

void GHTree() {
    rep(i,2,V) p[i] = 1;
    rep(i,2,V) if (p[i]) {
        G.init(i,p[i],V);
        w[i] = G.Dinic();
        rep(j,i+1,V) if (bel[j] && p[j]==p[i]) p[j] = i;
    }
}

struct edge {
	ll j,f,d; edge *nx,*op,*pr;
    double a; bool y;
}e[maxm],*v[maxn],*o = e,*del;
ll en;

inline void add_e(ll i,ll j,ll d,ll x,ll y) {
	e[++en].nx = v[i]; v[i] = v[i]->pr = e+en; v[i]->j = j; v[i]->d = d;
    e[++en].nx = v[j]; v[j] = v[j]->pr = e+en; v[j]->j = i; v[j]->d = d;
    v[i]->op = v[j]; v[j]->op = v[i];
    v[i]->a = atan2(y,x); v[j]->a = atan2(-y,-x);
    v[i]->y = v[j]->y = 1;
    v[i]->f = v[j]->f = 1;
}

inline void del_e(ll i,edge *e) {
    if (e==v[i]) v[i] = e->nx, v[i]->pr = o;
    else e->pr->nx = e->nx, e->nx->pr = e->pr;
}

double angle(double a,double b) {
    if (b<a) b += 2*pi;
    return b-a;
}

void visit(ll i) {
    vis[i] = 1;
    for (edge *e=v[i]; e!=o; e=e->nx) if (e!=del && e!=del->op)
        if (!vis[e->j]) visit(e->j);
}

void check() {
    edge *e,*nx;
    rep(i,1,cnt) for (e=v[i]; e!=o; e=nx) {
        nx = e->nx;
        del = e;
        memset(vis,0,sizeof(vis));
        visit(i);
        if (!vis[e->j]) del_e(i,e),del_e(e->j,e->op);
    }
}

void dual() {
    ll i,j,k; edge *e,*em; double am;
    V = 1;
    rep(u,1,cnt) for (edge *ef=v[u]; ef!=o; ef=ef->nx) if (ef->y) {
        e = ef; i = u; j = e->j;
        e->y = 0; e->f = ++V;
        while (j!=u) {
            em = 0; am = 0;
            for (edge *eg=v[j]; eg!=o; eg=eg->nx) if (eg->y && eg!=e->op) {
                double a = angle(e->op->a,eg->a);
                if (a>am) em = eg,am = a;
            }
            e = em; i = j; j = e->j;
            e->y = 0; e->f = V;
        }
    }

    C.clear();
    rep(i,1,cnt) for (edge *ef=v[i]; ef!=o; ef=ef->nx) if (ef->f < ef->op->f) {
        C[PII(ef->f,ef->op->f)] += ef->d;
    }
}

int main() {
    freopen("J.in" , "r" , stdin) ;
    ll i,j,k,t,tt,Test;
    get(Test);
    rep(Ti,1,Test) {
        get(m);
        cnt = 0; id.clear();
        en = 0; rep(i,0,maxn-1) v[i] = o;
        rep(k,1,m) {
            ll x1,y1,x2,y2;
            get(x1); get(y1); get(x2); get(y2); get(t);
            ll &i = id[PII(x1,y1)],&j = id[PII(x2,y2)];
            if (!i) i = ++cnt;
            if (!j) j = ++cnt;
            x2 -= x1; y2 -= y1;
            add_e(i,j,t,x2,y2);
        }
        check();
        dual();

        GHTree();
        ll ans = 0;
        rep(i,1,V) ans += w[i];
        printf("Case #%lld: %lld\n",Ti,ans);
    }
    fprintf(stderr, "Used: %fs\n", (double) clock() / CLOCKS_PER_SEC);
    for (;;) ;
    return 0;
}
