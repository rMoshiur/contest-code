#include <iostream>
#include <cstring>
#include <cstdio>
#include <unordered_map>
#include <ctime>
using namespace std ;
typedef long long LL ;
#define MP make_pair

const int MAXN = 809 ;
const int MAXM = 10 ;
const int MOD  = 1000000007 ;

int N , M ;
char Map[MAXN][MAXM] ;
unordered_map< int , pair<int,int> > F[MAXN][MAXM] ;
int LR[MAXN][MAXM] , UD[MAXN][MAXM] ;

void Init() {
    cin >> N >> M ;
    for ( int i = 0 ; i <= N+1 ; i ++ ) for ( int j = 0 ; j <= M+1 ; j ++ ) LR[i][j] = UD[i][j] = 1000000 ;
    UD[0][1] = 0 ;
    for ( int i = 1 ; i <= N ; i ++ ) for ( int j = 1 ; j <= M-1 ; j ++ ) cin >> LR[i][j] ;
    for ( int i = 1 ; i <= N-1 ; i ++ ) for ( int j = 1 ; j <= M ; j ++ ) cin >> UD[i][j] ;
}

bool RightBoundary( int x ) { return (x>>1)%2 ; }

bool LeftBoundary( int x ) { return x%2 ; }

int getinfo( int s , int i ) { return (s >> (2*i-2)) % 4 ; }

void ChangeBit( int &a , const int i , const int z ) {
    int _z = getinfo(a , i) ;
    a -= (_z << (2*i-2)) ;
    a += ( z << (2*i-2)) ;
}

void InsertLeftBra( int &s , int i ) { // from i to M
    for ( int j = i , c = 0 ; j <= M ; j ++ ) {
        int z = getinfo(s , j) ;
        if ( !LeftBoundary(z) && c == 0 ) {
            ChangeBit(s , j , z+1) ;
            break ;
        }
        if ( LeftBoundary(z) ) c ++ ;
        if ( RightBoundary(z) ) c -- ;
    }
}

void DeleteLeftBra(int &s , int i) { // from i to 1
    for ( int j = i , c = 0 ; j >= 1 ; j -- ) {
        int z = getinfo(s , j) ;
        if ( RightBoundary(z) ) c ++ ;
        if ( LeftBoundary(z) && c == 0 ) {
            ChangeBit(s , j , z-1) ;
            break ;
        }
        if ( LeftBoundary(z) ) c -- ;
    }
}

void DeleteRightBra(int &s , int i) { // from i to M
    for ( int j = i , c = 0 ; j <= M ; j ++ ) {
        int z = getinfo(s , j) ;
        if ( LeftBoundary(z) ) c ++ ;
        if ( RightBoundary(z) && c == 0 ) {
            ChangeBit(s , j , z-2) ;
            break ;
        }
        if ( RightBoundary(z) ) c -- ;
    }
}

void InsertRightBra(int &s , int i) { // from i to 1
    for ( int j = i , c = 0 ; j >= 1 ; j -- ) {
        int z = getinfo(s , j) ;
        if ( !RightBoundary(z) && c == 0 ) {
            ChangeBit(s , j , z+2) ;
            break ;
        }
        if ( RightBoundary(z) ) c ++ ;
        if ( LeftBoundary(z) ) c -- ;
    }
}

int RightExpand( int s , int i ) {
    int x = getinfo(s , i) , y = getinfo(s , i+1) , s2 = s ;
    if ( LeftBoundary(y) ) InsertLeftBra(s2 , i+2) ;
    if ( RightBoundary(y) ) InsertRightBra(s2 , i) ;
    s2 = s2 - (y << (2*i)) ;
    if ( RightBoundary(x) ) s2 = s2 - (x << (2*i-2)) + ((x-2) << (2*i-2)) + (2 << (2*i)) ;
    return s2 ;
}

int Union( int s , int i ) {
    int x = getinfo(s , i) , y = getinfo(s , i+1) , s2 = s ;
    if ( RightBoundary(x) && LeftBoundary(y) ) {
        ChangeBit(s2 , i , x-2) ;
        ChangeBit(s2 , i+1 , y-1) ;
    } else {
        if ( RightBoundary(x) ) {
            ChangeBit(s2 , i , x-2) ;
            DeleteLeftBra(s2 , i) ;
        }
        if ( LeftBoundary(y) ) {
            ChangeBit(s2 , i+1 , y-1) ;
            DeleteRightBra(s2 , i+1) ;
        }
    }
    return s2 ;
}

int Insert( int s , int i ) {
    int y = getinfo(s , i) , s2 = s ;
    if ( LeftBoundary(y) ) InsertLeftBra(s2 , i+1) ;
    if ( RightBoundary(y) ) InsertRightBra(s2 , i-1) ;
    s2 = s2 - (y << (2*i-2)) + (3 << (2*i-2)) ;
    return s2 ;
}

void Refresh( pair<int,int> &a , const pair<int,int> b , const int c , int rep ) {
    if ( a.second == 0 || b.first + c < a.first ) a = MP(b.first + c , ((LL)rep * (LL)b.second) % MOD) ;
    else if ( b.first + c == a.first ) a.second = ((LL)a.second + (LL)rep * (LL)b.second) % MOD ;
}

void Trans( int i , int j , int s ) {
    int x = getinfo(s , j) , y = getinfo(s , j+1) , s2 ;
    if ( RightBoundary(x) || LeftBoundary(y) ) { // x & y belong to different components
        s2 = s ;
        Refresh( F[i][j+1][s2] , F[i][j][s] , UD[i-1][j+1] , 2 ) ;
        if ( y != 3 ) {
            s2 = RightExpand(s , j) ; // Expand j to j+1
            Refresh( F[i][j+1][s2] , F[i][j][s] , LR[i][j] , 2 ) ;
            s2 = Insert(s , j+1) ; // Insert the independent plug in j+1
            Refresh( F[i][j+1][s2] , F[i][j][s] , 0 , 1 ) ;
        }
        s2 = Union(s , j) ; // Union j & j+1
        Refresh( F[i][j+1][s2] , F[i][j][s] , LR[i][j] + UD[i-1][j+1] , 3 ) ;
    } else {
        s2 = s ;
        Refresh( F[i][j+1][s2] , F[i][j][s] , LR[i][j] , 2 ) ;
        Refresh( F[i][j+1][s2] , F[i][j][s] , UD[i-1][j+1] , 2 ) ;
        
        s2 = Insert(s , j+1) ; // Insert the independent plug in j+1
        Refresh( F[i][j+1][s2] , F[i][j][s] , 0 , 1 ) ;
    }
}

void Solve() {
    for ( int i = 0 ; i <= N ; i ++ ) for ( int j = 1 ; j <= M ; j ++ ) F[i][j].clear() ;
    F[0][M][(1<<(2*M-1)) + 1] = MP(0 , 1) ;
    
    for ( int i = 1 ; i <= N ; i ++ ) {
        for ( auto it : F[i-1][M] ) {
            int s = it.first ;
            if ( i == 1 ) Refresh( F[i][1][s] , F[i-1][M][s] , UD[i-1][1] , 1 ) ;
            else          Refresh( F[i][1][s] , F[i-1][M][s] , UD[i-1][1] , 2 ) ;
            int x = getinfo(s , 1) , s2 = s ;
            if ( x != 3 && i > 1 ) {
                InsertLeftBra( s2 , 2 ) ;
                ChangeBit( s2 , 1 , 3 ) ;
                Refresh( F[i][1][s2] , F[i-1][M][s] , 0 , 1 ) ;
            }
        }
        for ( int j = 1 ; j < M ; j ++ )
            for ( auto it : F[i][j] )
                Trans( i , j , it.first ) ;
    }
}

int main() {
    freopen("escape_large.in" , "r" , stdin) ;
    freopen("escape_large.out", "w" ,stdout) ;
    
    int Test ; cin >> Test ;
    for ( int i = 1 ; i <= Test ; i ++ ) {
        Init() ;
        Solve() ;
        cout << "Case #" << i << ": " << F[N][M][(1<<(2*M-1)) + 1].first << " " << F[N][M][(1<<(2*M-1)) + 1].second << "\n" ;
    }
	fprintf(stderr,"%.2f s\n",clock()*1.0/CLOCKS_PER_SEC);
	for (;;) ;
}
