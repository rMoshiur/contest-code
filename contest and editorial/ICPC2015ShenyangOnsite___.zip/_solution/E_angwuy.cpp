#include <cstdio>
#include <cstring>
#include <ctime>

struct Hash{
	static const int MAXH = 100007;
	
	int t;
	int chk[MAXH];
	int num[MAXH];
	int min[MAXH];
	int cnt[MAXH];
	int s[MAXH];
	int top;
	
	Hash() {t = 1; top = 0; memset(chk, 0, sizeof(chk));}
	
	void clear() { ++t; top = 0;}
	
	int access(int k)
	{
		int i = k % MAXH;
		while (chk[i] == t && num[i] != k) i = (i + 1) % MAXH;
		if (chk[i] != t)
		{
			chk[i] = t;
			num[i] = k;
			cnt[i] = 0;
			s[++top] = k;
		}
		return i;
	}
};

const int MAXN = 10;
const int MAXM = 8800;
const int MAXK = 6500;
const int MOD = 1000000007;
const int E3[] = {0, 0x000003, 0x00000c, 0x000030, 0x0000c0,
                     0x000300, 0x000c00, 0x003000, 0x00c000,
					 0x030000, 0x0c0000, 0x300000, 0xc00000};

int n, m, k;
bool a[MAXM][MAXM];
int r[MAXM][MAXM], d[MAXM][MAXM];
Hash f[2];
int curL;

void init()
{
	scanf("%d %d", &m, &n);
	int x, y;
	memset(a, true, sizeof(a));
	for (int j = 1; j <= m; ++j)
	for (int i = 1; i <= n; ++i)
		a[i][j] = false;
	for (int j = 1; j <= m; ++j)
	for (int i = 2; i <= n; ++i)
		scanf("%d", &r[i][j]);
	for (int j = 2; j <= m; ++j)
	for (int i = 1; i <= n; ++i)
		scanf("%d", &d[i][j]);
}

void updata(int flag, int k, int v, int c, int t)
{
	int i = f[flag].access(k);
	if (f[flag].cnt[i] == 0 || f[flag].min[i] > v)
	{
		f[flag].min[i] = v;
		f[flag].cnt[i] = (c * (t&2) % MOD + c * (t & 1))% MOD;
	}
	else if (f[flag].min[i] == v)
		f[flag].cnt[i] = ((f[flag].cnt[i] + c * (t & 2) % MOD) % MOD + c * (t & 1)) % MOD;
}

int get(int s, int k)
{
	if (k == 0) return 0;
	else return (s >> ((k - 1) << 1)) & 3;
}

int put(int s, int k, int num)
{
	return (s | E3[k]) - E3[k] + (num << ((k - 1) << 1));
}

int Chk(int c, int k)
{
	if (k >= c) return a[k][curL - 1];
	else          return a[k][curL];
}

int Z(int s, int k)
{
	int c = k;
	if (get(s, k) == 1)
	{
		int t = 0;
		for (++k;;++k)
		if (!Chk(c, k))
		{
			int c = get(s, k);
			if (c == 0 && t == 0) return put(s, k, 1);
			else if (c == 1) ++t;
			else if (c == 2)
			{
				if (t == 0) return put(s, k, 3);
				else --t;
			}
		}
	}
	else if (get(s, k) == 2)
	{
		int t = 0;
		for (--k;;--k)
		if (!Chk(c, k))
		{
			int c = get(s, k);
			if (c == 0 && t == 0) return put(s, k, 2);
			else if (c == 2) ++t;
			else if (c == 1)
			{
				if (t == 0) return put(s, k, 3);
				else --t;
			}
		}
	}
}

int Y(int s, int k)
{
	if (get(s, k) == 1)
	{
		int t = 0;
		for (++k;;++k)
		{
			int c = get(s, k);
			if (c == 1) ++t;
			else if (c == 2)
			{
				if (t == 0) return put(s, k, 0);
				else --t;
			}
		}
	}
	else if (get(s, k) == 2)
	{
		int t = 0;
		for (--k;;--k)
		{
			int c = get(s, k);
			if (c == 2) ++t;
			else if (c == 1)
			{
				if (t == 0) return put(s, k, 0);
				else --t;
			}
		}
	}
}

void solve()
{
	int cur = 0;
	int last = 1;
	f[cur].clear();
	updata(0, 0, 0, 1, 1);
	for (int j = 1; j <= m; ++j)
	for (int i = 1; i <= n; ++i)
	{
		curL = j;
		cur ^= 1; last ^= 1;
		f[cur].clear();
		for (int ii = 1; ii <= f[last].top; ++ii)
		{
			int s = f[last].s[ii];
			int si = f[last].access(s);
			int minv = f[last].min[si];
			int cnt  = f[last].cnt[si];
			int u = get(s, i);
			int l = get(s, i - 1);
			if (a[i][j])
			{
				if (u == 0)
					updata(cur, put(s, i, 0), minv, cnt, 1);
				else if (u == 1 || u == 2)
					updata(cur, put(Z(s, i), i, 0), minv, cnt, 1);
			}
			else if (a[i - 1][j] && a[i][j - 1])
			{
				updata(cur, put(s, i, 3), minv, cnt, 1);
			}
			else if (a[i][j - 1] && !a[i-1][j])
			{
				updata(cur, put(s, i, 3), minv, cnt, 1);
				if (l == 0)
					updata(cur, put(s, i, 0), minv + r[i][j], cnt, 2);
				else if (l == 1)
					updata(cur, put(s, i, 0), minv + r[i][j], cnt, 2);
				else if (l == 2)
					updata(cur, put(put(s, i-1, 0), i, 2), minv + r[i][j], cnt, 2);
				else
					updata(cur, put(put(s, i-1, 1), i, 2), minv + r[i][j], cnt, 2);
			}
			else if (!a[i][j-1] && a[i-1][j])
			{
				updata(cur, s, minv + d[i][j], cnt, 2);
				if (u == 0)
					updata(cur, put(s, i, 3), minv, cnt, 1);
				else if (u < 3)
					updata(cur, put(Z(s, i), i, 3), minv, cnt, 1);
			}
			else
			{
				if (u == 0) updata(cur, put(s, i, 3), minv, cnt, 1);
				else if (u == 1) updata(cur, put(Z(s, i), i, 3), minv, cnt, 1);
				else if (u == 2)
				{
					if (l == 0) updata(cur, put(put(s, i, 3), i - 1, 2), minv, cnt, 1);
					else if (l == 1) updata(cur, put(put(s, i, 3), i - 1, 3), minv, cnt, 1);
					else updata(cur, put(Z(s, i), i, 3), minv, cnt, 1);
				}
				
				if (u == 0)
				{
					if (l == 0 || l == 1) updata(cur, s, minv + r[i][j], cnt, 2);
					else if (l == 2) updata(cur, put(put(s, i, 2), i - 1, 0), minv + r[i][j], cnt, 2);
					else updata(cur, put(put(s, i, 2), i - 1, 1), minv + r[i][j], cnt, 2);
				}
				else if (u == 1)
				{
					if (l == 0 || l == 1) updata(cur, put(Z(s, i), i, 0), minv + r[i][j], cnt, 2);
					else if (l == 2) updata(cur, put(put(Z(s, i), i, 2), i - 1, 0), minv + r[i][j], cnt, 2);
					else updata(cur, put(put(Z(s, i), i, 2), i - 1, 1), minv + r[i][j], cnt, 2);
				}
				else if (u == 2)
				{
					if (l == 0 || l == 1) updata(cur, s, minv + r[i][j], cnt, 2);
					else if (l == 2) updata(cur, put(Z(s, i), i - 1, 0), minv + r[i][j], cnt, 2);
					else updata(cur, put(Z(s, i), i - 1, 1), minv + r[i][j], cnt, 2);
				}
				
				updata(cur, s, minv + d[i][j], cnt, 2);
				
				if (u == 0)
				{
					if (l == 2) updata(cur, put(Y(s, i - 1), i - 1, 0), minv + r[i][j] + d[i][j], cnt, 3);
					else if (l == 3) updata(cur, put(s, i - 1, 0), minv + r[i][j] + d[i][j], cnt, 3);
				}
				else if (u == 1)
				{
					if (l == 0 || l == 1) updata(cur, put(Y(s, i), i, 0), minv + r[i][j] + d[i][j], cnt, 3);
					else if (l == 2) updata(cur, put(put(s, i, 0), i - 1, 0), minv + r[i][j] + d[i][j], cnt, 3);
					else updata(cur, put(put(s, i, 0), i - 1, 1), minv + r[i][j] + d[i][j], cnt, 3);
				}
				else if (u == 2)
				{
					if (l == 2) updata(cur, put(Y(s, i - 1), i - 1, 0), minv + r[i][j] + d[i][j], cnt, 3);
					else if (l == 3) updata(cur, put(s, i - 1, 0), minv + r[i][j] + d[i][j], cnt, 3);
				}
				else
				{
					if (l == 0 || l == 1) updata(cur, put(s, i, 0), minv + r[i][j] + d[i][j], cnt, 3);
					else if (l == 2) updata(cur, put(put(s, i, 2), i - 1, 0), minv + r[i][j] + d[i][j], cnt, 3);
					else  updata(cur, put(put(s, i, 2), i - 1, 1), minv + r[i][j] + d[i][j], cnt, 3);
				}
			}
		}
	}
	int ans = 0;
	for (int i = 1; i <= n; ++i)
	if (!a[i][m])
	{
		ans = put(ans, i, 1);
		break;
	}
	for (int i = n; i >= 1; --i)
	if (!a[i][m])
	{
		if (get(ans, i) == 0)
			ans = put(ans, i, 2);
		else
			ans = put(ans, i, 3);
		break;
	}
	int ansi = f[cur].access(ans);
	printf("%d %d\n", f[cur].min[ansi], f[cur].cnt[ansi]);
}

int main()
{
	freopen("escape_large.in", "r", stdin);
	freopen("escape_large.out", "w", stdout);
	int t;
	scanf("%d", &t);
	for (int i = 1; i <= t; ++i)
	{
		init();
		printf("Case #%d: ", i);
		solve();
	}
	fprintf(stderr,"%.2f\n",clock()*1.0/CLOCKS_PER_SEC);
	for(;;);
	return 0;
}
