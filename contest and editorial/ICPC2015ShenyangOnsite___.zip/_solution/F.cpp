#include<bits/stdc++.h>
#define rep(i,s,t) for (i=(s); i<=(t); ++i)

using namespace std;

typedef long long ll;
const ll maxn = 10010;
ll n,a[maxn],m;
vector<ll> fac;

ll phi(ll x) {
    if (x==1) return 0;
    ll y,r = x;
    for (y=2; y*y<=x; ++y) if (x%y==0) {
        r = r/y*(y-1);
        while (x%y==0) x /= y;
    }
    return x>1? r/x*(x-1) : r;
}

int main() {
    freopen("frogs.in","r",stdin);
    freopen("frogs.out","w",stdout);
    ll i,j,k,t,tt,Test,Ti;
    scanf("%lld",&Test);
    rep(Ti,1,Test) {
        scanf("%lld%lld",&n,&m);
        rep(i,1,n) scanf("%lld",&t),a[i] = __gcd(t,m);
        fac.clear();
        for (i=1; i*i<=m; ++i) if (m%i==0) {
            fac.push_back(i);
            if (i*i!=m) fac.push_back(m/i);
        }
        sort(a+1,a+n+1);
        n = unique(a+1,a+n+1) - a - 1;
        tt = 0;
        for (ll x:fac) rep(i,1,n)
            if (x%a[i]==0) { tt += m*phi(m/x)/2; break; }
        printf("Case #%lld: %lld\n",Ti,tt);
    }
	fprintf(stderr,"%.2f s\n",clock()*1.0/CLOCKS_PER_SEC);
    return 0;
}
