#include<iostream>
#include<stdio.h>
#include<string.h>
#include<vector>
#include<ctime>
#include<algorithm>
using namespace std;
long long dis[100000+10];
long long dis2[100000+10];
vector<vector<int>> E;
vector<int> e[100000+10];
vector<int> w;
vector<bool> f;
vector<int> inh;
struct x
{
    int id,w;
};
vector<struct x> heap;
void decrease(int i)
{
    if(i!=1 && heap[i/2].w > heap[i].w)
    {
        inh[heap[i].id]=i/2;
        inh[heap[i/2].id]=i;
        struct x tmp;
        tmp = heap[i];
        heap[i]=heap[i/2];
        heap[i/2]=tmp;
        decrease(i/2);
    }
}
void pop(int i)
{
    if(i*2<heap.size())
    {
        int j = i*2;
        if(i*2+1 < heap.size())
        {

            if(heap[j].w > heap[i*2+1].w)
            {
                j=i*2+1;
            }
        }
        if(heap[i].w> heap[j].w)
        {
            inh[heap[i].id]=j;
            inh[heap[j].id]=i;
            struct x tmp;
            tmp = heap[i];
            heap[i]=heap[j];
            heap[j]=tmp;
            pop(j);
        }
    }
}
void sp(int start)
{
    for(int i=0;i<inh.size();i++)inh[i]=-1,f[i]=false;

    heap.clear();
    struct x nouse;
    heap.push_back(nouse);
    memset(dis,-1,sizeof(dis));
    dis[start]=0;
    for(int i=0;i<e[start].size();i++)
    {
        struct x tmp;
        tmp.id = e[start][i];
        tmp.w = w[tmp.id];
        if(inh[tmp.id]==-1)
        {
            inh[tmp.id]=heap.size();
            heap.push_back(tmp);
            decrease(heap.size()-1);
        }
    }
    while(heap.size()>1)
    {
        struct x tmp = heap[1];
        //cout<<tmp.id<<' '<<tmp.w<<' '<<heap.size()<<' '<<f[tmp.id]<<endl;
        heap[1]=heap.back();
        heap.pop_back();
        pop(1);
        if(f[tmp.id] == true)continue;
        f[tmp.id]=true;
        for(int i=0;i<E[tmp.id].size();i++)
        {
            int node = E[tmp.id][i];
            if(dis[node]==-1)
            {
                dis[node]=tmp.w;
                for(int j=0;j<e[node].size();j++)
                {
                    int xx = e[node][j];
                    if(f[xx]==false)
                    {
                        if(inh[xx]==-1)
                        {

                            struct x tmpp;
                            tmpp.id=xx;
                            tmpp.w =tmp.w+w[xx];
                            //cout<<"push "<<tmp.id<<' '<<tmp.w<<endl;
                            inh[xx]=heap.size();
                            heap.push_back(tmpp);
                            decrease(heap.size()-1);
                        }else
                        {
                            if(heap[inh[xx]].w > tmp.w+w[xx])
                            {
                                heap[inh[xx]].w = tmp.w+w[xx];
                                decrease(inh[xx]);
                            }
                        }
                    }
                }
            }
        }
    }
}
int main()
{
    freopen("M.in" , "r" , stdin) ;
    freopen("M.out", "w" ,stdout) ;
    
    int T,Case=0,n,m;
    int i,j,k;
    scanf("%d",&T);
    while(T--){
        E.clear();w.clear();f.clear();inh.clear();
        cin>>n;
        for(i=1;i<=n;i++)e[i].clear();
        cin>>m;
        for(i=0;i<m;i++)
        {
            int s,ww;
            vector<int> tmp;
            scanf("%d%d",&ww,&s);
            w.push_back(ww);
            f.push_back(false);
            inh.push_back(-1);
            for(j=0;j<s;j++)
            {
                scanf("%d",&k);
                tmp.push_back(k);
                e[k].push_back(i);
            }
            E.push_back(tmp);
        }
        sp(n);
//        for(i=1;i<=n;i++)
//        {
//            cout<<dis[i]<<' ';
//        }
//        cout<<endl;
        memcpy(dis2,dis,sizeof(dis));
        sp(1);
//        for(i=1;i<=n;i++)
//        {
//            cout<<dis[i]<<' ';
//        }
//        cout<<endl;
        if(dis[n]==-1)
        {
            cout<<"Case #"<<++Case<<": Evil John"<<endl;
            continue;
        }
        long long ans = dis[n];
        vector<int> va;va.push_back(1),va.push_back(n);
        for(i=2;i<n;i++)
        {
            if(dis2[i]==-1||dis[i]==-1) continue;
            long long minn=max(dis2[i],dis[i]);
            if(minn<ans)
            {
                va.clear();
                va.push_back(i);
                ans=minn;
            }else if(minn == ans)
            {
                va.push_back(i);
            }
        }
        cout<<"Case #"<<++Case<<": "<<ans<<endl;
        sort(va.begin(),va.end());
        for(i=0;i<(int)va.size()-1;i++)
        {
            printf("%d ",va[i]);
        }
        if(!va.empty()) printf("%d\n",va.back());
    }
    fprintf(stderr,"%.2f\n",1.0*clock()/CLOCKS_PER_SEC);
    for (;;) ;
}
