#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
#include<ctime>
#define N 5010
#define M 20100
#define inf 1023456789
using namespace std;
int to[M<<1],nxt[M<<1],w[M<<1],c[M<<1],cnt;
int head[N],from[N],src,dst;
bool in[N];
int dis[N];
void add_edge(int u,int v,int _w,int _c){
	to[cnt]=v,nxt[cnt]=head[u],w[cnt]=_w,c[cnt]=_c,head[u]=cnt++;
	to[cnt]=u,nxt[cnt]=head[v],w[cnt]=-_w,c[cnt]=0,head[v]=cnt++;
}
void init(int _src,int _dst){
	src=_src,dst=_dst;
	cnt=0;
	memset(head,-1,sizeof(head));
}
int sp(){
	memset(dis,-1,sizeof(dis));
	queue<int> q;
	in[src]=true;
	q.push(src);
	dis[src]=0;
	while(!q.empty()){
		int u=q.front();
		q.pop();
		in[u]=false;
		if(dis[dst]!=-1&&dis[u]>=dis[dst]) continue;
		for(int i=head[u];i!=-1;i=nxt[i]){
			if(c[i]&&(dis[to[i]]==-1||dis[u]+w[i]<dis[to[i]])){
				dis[to[i]]=dis[u]+w[i];
				from[to[i]]=i;
				if(!in[to[i]]){
					in[to[i]]=true;
					q.push(to[i]);
				}
			}
		}
	}
	if(dis[dst]!=-1){
		for(int u=dst;u!=src;u=to[from[u]^1]){
			c[from[u]]--;
			c[from[u]^1]++;
		}
		return 1;
	}
	return 0;
}
int min_cost_flow(int ideg,int odeg){
	if(ideg!=odeg) return -1;
	int res=0;
	int tmp;
	while(tmp=sp()){
		ideg-=tmp;
		res+=dis[dst];
	}
	if(ideg) return -1;
	else return res;
}
int bd[50][50];
int main(){
    freopen("L.in" , "r" , stdin) ;
    freopen("L.out", "w" ,stdout) ;
    
	int T;
	scanf("%d",&T);
	for(int cs=1;cs<=T;cs++){
		int n,m,ideg=0,odeg=0,x;
		scanf("%d%d",&n,&m);
		init(n*m*2,n*m*2+1);
		for(int i=0;i<n;i++){
			for(int j=0;j<m;j++){
				scanf("%d",&bd[i][j]);
				if(bd[i][j]==0){
					add_edge(src,i*m+j,0,1);
					add_edge(n*m+i*m+j,dst,0,1);
					ideg++;
					odeg++;
				}
				else if(bd[i][j]%2==0){
					add_edge(src,i*m+j,0,1);
					ideg++;
				}
				else{
					add_edge(n*m+i*m+j,dst,0,1);
					odeg++;
				}
			}
		}
		for(int i=1;i<n;i++){
			for(int j=0;j<m;j++){
				scanf("%d",&x);
				int u=(i-1)*m+j,v=i*m+j;
				if(bd[i-1][j]%2==0){
					add_edge(u,v+n*m,x,1);
				}
				if(bd[i][j]%2==0){
					add_edge(v,u+n*m,x,1);
				}
			}
		}
		for(int i=0;i<n;i++){
			for(int j=1;j<m;j++){
				scanf("%d",&x);
				int u=i*m+j-1,v=i*m+j;
				if(bd[i][j-1]%2==0){
					add_edge(u,v+n*m,x,1);
				}
				if(bd[i][j]%2==0){
					add_edge(v,u+n*m,x,1);
				}
			}
		}
		printf("Case #%d: %d\n",cs,min_cost_flow(ideg,odeg));
	}
	
	fprintf(stderr,"%.2f s\n",clock()*1.0/CLOCKS_PER_SEC);
	for (;;) ;
	return 0;
}
