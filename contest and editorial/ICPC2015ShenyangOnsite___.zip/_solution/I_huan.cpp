#include<bits/stdc++.h>
#define rep(i,s,t) for (ll i=(s); i<=(t); ++i)
#define dep(i,t,s) for (ll i=(t); i>=(s); --i)
#define i first
#define j second
#define pb push_back
#define qb pop_back
#define pf push_front
#define qf pop_front
#define sz(x) ll((x).size())
#define p(i) (1LL<<((i)-1))
#define w(x,i) ((x)&p(i))

using namespace std;

template<class T> inline T pr(T x) { return --x; }
template<class T> inline T nx(T x) { return ++x; }
template<class T> inline T sqr(T x) { return x*x; }

template<class T>
inline void get(T &n) {
	char c = getchar();
	while (c!='-' && (c<'0' || c>'9')) c = getchar();
	n = 0; T s = 1; if (c=='-') s = -1,c = getchar();
	while (c>='0' && c<='9') n*=10,n+=c-'0',c=getchar();
	n *= s;
}

typedef long long ll;
typedef pair<ll,ll> PII;

const ll maxn = 100010,maxc = 1010;
ll n,m,bit[maxc][maxc];
map<ll,ll> a[maxn];
map<PII,ll> b[maxn];
map<PII,ll> cnt[maxn];

void ins(ll x,ll y) {
    for (ll i=x; i<=1000; i+=i&-i)
        for (ll j=y; j<=1000; j+=j&-j)
            ++bit[i][j];
}

ll sum(ll x,ll y) {
    ll r = 0;
    for (ll i=x; i; i-=i&-i)
        for (ll j=y; j; j-=j&-j)
            r += bit[i][j];
    return r;
}

int main() {
    freopen("I.in","r",stdin);
    ll i,j,k,t,tt,Test;
    get(Test);
    rep(Ti,1,Test) {
        get(n); get(m);
        rep(i,0,maxn-1) a[i].clear(),b[i].clear(),cnt[i].clear();
        rep(k,1,n) {
            get(i); get(j);
            ++a[j][i];
        }
        rep(kk,1,m) {
            get(i); get(j); get(k);
            ++b[k][PII(i,j)];
        }
        rep(c,0,maxn-1) if (sz(a[c]) && sz(b[c])) {
            auto ti = --a[c].end();
            k = ti->i; t = ti->j;
            for (auto x:b[c]) {
                i = x.i.i; j = x.i.j; tt = x.j;
                i = 1000-i+1; j = 1000-j+1;
                cnt[k][{i,j}] += t*tt;
            }
        }
        memset(bit,0,sizeof(bit));
        ll ans = 0;
        dep(c,maxn-1,0) {
            for (auto x:cnt[c]) ins(x.i.i,x.i.j);
            for (auto x:cnt[c]) {
                i = x.i.i; j = x.i.j; t = x.j;
                if (sum(i,j)==1) ans += t;
            }
        }
        printf("Case #%lld: %lld\n",Ti,ans);
    }
	fprintf(stderr,"%.2f s\n",clock()*1.0/CLOCKS_PER_SEC);
	for (;;);
    return 0;
}
