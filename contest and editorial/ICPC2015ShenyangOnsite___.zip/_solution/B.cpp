#include <cstdio>
#include <cstring>
#include <iostream>
#include <ctime>
using namespace std ;

const int NR = 5010 ;

int len[NR] , n , P[NR] ;
char s[NR][NR] ;

bool Check(int B , int A) {
    P[1] = 0 ;
    int j = 0 ;
    for ( int i = 2 ; i <= len[B] ; i ++ ) {
        while ( j > 0 && s[B][j+1] != s[B][i] ) j = P[j] ;
        if ( s[B][j+1] == s[B][i] ) j ++ ;
        P[i] = j ;
    }
    j = 0 ;
    for ( int i = 1 ; i <= len[A] ; i ++ ) {
        while ( j > 0 && s[B][j+1] != s[A][i] ) j = P[j] ;
        if ( s[B][j+1] == s[A][i] ) j ++ ;
        if ( j == len[B] ) return true ;
    }
    return false ;
}

int main() {
    freopen("B.in" , "r" , stdin) ;
    freopen("B.out", "w" ,stdout) ;
	int Test ; scanf("%d" , &Test) ;
	for ( int _ = 1 ; _ <= Test ; _ ++ ) {
        scanf("%d" , &n) ;
        for ( int i = 1 ; i <= n ; i ++ ) scanf("%s", s[i] + 1) , len[i] = strlen(s[i] + 1) ;
        int p = n ;
        while ( p && Check(p - 1 , p) ) p -- ;
        if ( !p ) printf("Case #%d: -1\n" , _) ;
        else {
            int p0 = 1 , p1 = p , ans = p ;
            for ( ; p1 <= n ; p1 ++ ) {
                while ( p0 <= p1 && Check(p0, p1) ) p0 ++ ;
                if ( p0 <= p1 ) ans = p1 ;
            }
            printf("Case #%d: %d\n", _, ans) ;
        }
    }
	fprintf(stderr,"%.2f s\n",clock()*1.0/CLOCKS_PER_SEC);
	for (;;);
}
