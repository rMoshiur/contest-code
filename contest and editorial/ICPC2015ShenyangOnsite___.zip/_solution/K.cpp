#include<bits/stdc++.h>
#define rep(i,s,t) for (ll i=(s); i<=(t); ++i)
#define dep(i,t,s) for (ll i=(t); i>=(s); --i)
#define i first
#define j second
#define pb push_back
#define pp pop_back
#define pf pop_front
#define sz(x) ll((x).size())
#define p(i) (1LL<<((i)))
#define w(x,i) ((x)&p(i))

using namespace std;

typedef long long ll;
typedef pair<ll,ll> PII;

template<class T> inline T pr(T x) { return --x; }
template<class T> inline T nx(T x) { return ++x; }
template<class T> inline T sqr(T x) { return x*x; }

template<class T>
inline void get(T &n) {
	char c = getchar();
	while (c!='-' && (c<'0' || c>'9')) c = getchar();
	n = 0; T s = 1; if (c=='-') s = -1,c = getchar();
	while (c>='0' && c<='9') n*=10,n+=c-'0',c=getchar();
	n *= s;
}

const ll maxn = 7010,maxp = 130,mo = ll(1e9)+7;
const ll m = 4,mask = (1<<(m+1))-1;
ll n,a[10],f[maxn][maxp],s[maxp];
ll r[maxp],cnt[maxp];
ll fr[maxn] , invfr[maxn] ;
vector<ll> g[maxp];

inline void add(ll &a,ll b) {
    a += b;
    if (a>=mo) a -= mo;
}

ll power(ll a,ll b) {
    if ( b == 0 ) return 1 ;
    if ( b == 1 ) return a ;
    if ( b % 2 == 0 ) {
        ll r = power(a , b/2) ;
        return (r * r) % mo ;
    } else {
        return (a * power(a , b-1)) % mo ;
    }
}

ll Combination(ll a , ll b) {
    if ( b > a ) return 0 ;
    return (((fr[a] * invfr[b]) % mo) * invfr[a-b]) % mo ;
}

ll calc() {
    ll ret = 0,t,tmp,base,j,z,p,q;
    rep(x,0,mask) {
        s[x] = 0;
        rep(i,0,m)
            if (w(x,i)) s[x] += a[i] + 1;
    }
    rep(x,0,mask) {
        base = m+1 - cnt[x];
        for (ll y:g[x]) f[0][y] = 0;
        f[0][0] = 1;
        rep(i,1,n) for (ll y:g[x]) {
            f[i][y] = f[i-1][y] * (base + cnt[y])%mo;
            if (s[y]>i) continue;
            for (t=y; t; t-=t&-t) {
                j = r[t&-t]; z = y-(t&-t);
                add(f[i][y],Combination(i-1,a[j]) * f[i-a[j]-1][z]%mo);
            }
        }
        tmp = (cnt[x]&1) ? (mo-f[n][x])%mo : f[n][x];
        add(ret,tmp);
    }
    return ret;
}

int main() {
    freopen("K_sample.in" , "r" , stdin) ;
    freopen("K_sample.out", "w" ,stdout) ;
    ll i,j,k,t,tt,test;
    
    fr[0] = 1;
    rep(i,1,7000) fr[i] = (fr[i-1] * i) % mo ;
    rep(i,0,7000) invfr[i] = power(fr[i] , mo-2) ;
    
    rep(x,0,mask) cnt[x] = __builtin_popcount(x);
    rep(x,0,mask) rep(y,0,mask) {
        bool ok = 1;
        rep(i,0,x)
            if (w(y,i) && !w(x,i)) ok = 0;
        if (ok) g[x].pb(y);
    }
    rep(i,0,m) r[p(i)] = i;

    get(test);
    rep(Ti,1,test) {
        get(n); rep(i,0,m) get(a[i]);
        ll ans = calc();
        if (a[0]) {
            --a[0]; --n;
            ans = (ans - calc() + mo)%mo;
        }
        printf("Case #%lld: %lld\n",Ti,ans);
    }

	fprintf(stderr,"%.2f s\n",clock()*1.0/CLOCKS_PER_SEC);
	for(;;);
    return 0;
}
