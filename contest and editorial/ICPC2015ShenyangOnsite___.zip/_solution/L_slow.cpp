//============================================================================
// Name        : L.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <cstdio>
#include <cstring>
#include <vector>
#include <ctime>
using namespace std;

const int max_size = 200;
int grid[max_size][max_size];

const int maxn = max_size * max_size * 2 + 100;
const int maxe = maxn * 10;
const int inf = 2147483647/2;
const int base = (1 << 20) - 1;
int a[maxn], first[maxn], top;
int c[maxe], f[maxe], cost[maxe], loc[maxe], next_edge[maxe], op[maxe];
int st, ed, n_nodes, n, m;
int q[base + 1], dist[maxn], pre[maxn], flow[maxn];
bool h[maxn];

void init_network(int _st, int _ed, int _n)
{
	memset(a, 0, sizeof(a));
	top = 0;
	st = _st;
	ed = _ed;
	n_nodes = _n;
}

void addedge(int x, int y, int upper, int toll)
{
	int p1 = ++top; loc[p1] = y; c[p1] = upper; f[p1] = 0; cost[p1] = toll; next_edge[p1] = a[x]; a[x] = p1;
	int p2 = ++top; loc[p2] = x; c[p2] = 0; f[p2] = 0; cost[p2] = -toll; next_edge[p2] = a[y]; a[y] = p2;
	op[p1] = p2; op[p2] = p1;
}

void SPFA(){
	memset(h, false, sizeof(h));
	h[st] = true;
	int head = 0, tail = 0;
	q[head] = st;
	pre[st] = -1;
	pre[ed] = -1;
	flow[st] = inf;
	for (int i = 0; i < n_nodes; ++i)
		dist[i] = inf;
	dist[st] = 0;
	while (head <= tail)
	{
		int k = q[head & base], p = a[k];
		while (p){
			int dst = loc[p];
			if (c[p] > f[p] && dist[k] + cost[p] < dist[dst])
			{
				dist[dst] = dist[k] + cost[p];
				pre[dst] = p;
				flow[dst] = min(flow[k], c[p] - f[p]);
				if (!h[dst])
				{
					h[dst] = true;
					q[(++tail) & base] = dst;
				}
			}
			p = next_edge[p];
		}
		h[k] = false;
		head++;
	}
}

void work(int &total_flow, int &total_cost){
	total_flow = total_cost = 0;
	do {
		SPFA();
		if (pre[ed] == -1)
			break;
		int delta = flow[ed], p = pre[ed];
		total_flow += delta;
		while (p != -1) {
			f[p] += delta;
			f[op[p]] = -f[p];
			total_cost += delta * cost[p];
			p = pre[loc[op[p]]];
		}
	} while (pre[ed] != -1);
}

int main() {
	freopen("L.in", "r", stdin);
	freopen("L.out", "w", stdout);
	int T;
	scanf("%d", &T);
	for (int casenum = 1; casenum <= T; ++casenum)
	{
		scanf("%d %d", &n, &m);
		printf("Case #%d: ", casenum);
		int N = n * m;
		init_network(N * 2 + 2, N * 2 + 3, N * 2 + 4);
		int num_odd = 0, num_even = 0;
		for (int i = 0; i < n; ++i)
			for (int j = 0; j < m; ++j)
			{
				scanf("%d", &grid[i][j]);
				if (grid[i][j])
				{
					if (grid[i][j] & 1)
						num_odd++;
					else
						num_even++;
				}
			}
		addedge(st, 2 * N + 1, num_even, 0);
		addedge(0, ed, num_odd, 0);

		addedge(2 * N + 1, 0, inf, 0);
		int toll;
		for (int i = 0; i < n - 1; ++i)
			for (int j = 0; j < m; ++j)
			{
				scanf("%d", &toll);
				addedge(i * m + j + 1 + N, (i + 1) * m + j + 1, 1, toll);
				addedge((i + 1) * m + j + 1 + N, i * m + j + 1, 1, toll);
			}

		for (int i = 0; i < n; ++i)
			for (int j = 0; j < m - 1; ++j)
			{
				scanf("%d", &toll);
				addedge(i * m + j + 1 + N, i * m + j + 2, 1, toll);
				addedge(i * m + j + 2 + N, i * m + j + 1, 1, toll);
			}

		for (int i = 0; i < n; ++i)
			for (int j = 0; j < m; ++j)
			{
				int idx = i * m + j + 1;
				if (grid[i][j])
				{
					if (grid[i][j] & 1)
						addedge(st, idx + N, 1, 0);
					else
						addedge(idx, ed, 1, 0);
				} else {
					addedge(st, idx + N, 1, 0);
					addedge(idx, ed, 1, 0);
				}
			}
		if (num_odd != num_even)
		{
			printf("-1\n");
			continue;
		}
		int total_flow, total_cost;
		work(total_flow, total_cost);
		if (total_flow != N)
			printf("-1\n");
		else
			printf("%d\n", total_cost);
	}
	fprintf(stderr,"%.2f s\n",clock()*1.0/CLOCKS_PER_SEC);
	for(;;);
	return 0;
}
