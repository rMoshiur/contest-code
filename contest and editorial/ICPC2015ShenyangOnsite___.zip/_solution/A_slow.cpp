#include <iostream>
#include <cstring>
#include <cstdio>
#include <vector>
#include <ctime>
#include <unordered_map>
using namespace std ;

#define MP make_pair

typedef unsigned long long LL ;

const int MAXN = 10000 ;
const int MAXLOGN = 16 ;
const int MAXM = 10 ;
const LL  P    = 37 ;

int K ;
LL totS , totT , sumlenT;
LL A[MAXN][MAXM] , B[MAXN][MAXM] , C[MAXN][MAXM] , D[MAXN][MAXM] ;
LL cntS[MAXN] , cntT[MAXN] , lenS[MAXN] , lenT[MAXN] ;
LL PowerPS[MAXN] , PowerPSS[MAXN] , PowerSumPS[MAXN] ;
LL PowerPT[MAXN] , PowerPTT[MAXN] , PowerSumPT[MAXN] ;
vector<string> SaveT ;
string S , T ;
LL STlenS[MAXN][MAXLOGN] , STPowerPSS[MAXN][MAXLOGN] , SThashS[MAXN][MAXLOGN] ;
LL STlenT[MAXN][MAXLOGN] , STPowerPTT[MAXN][MAXLOGN] , SThashT[MAXN][MAXLOGN] ;
unordered_map<LL,LL> SaveHashS ;

LL Power(LL x , LL t) {
    LL Ret = 1 , xx = x ;
    while ( t > 0 ) {
        if ( t & 1 ) Ret *= xx ;
        t >>= 1 ;
        xx = xx * xx ;
    }
    return Ret ;
}
LL PowerSum(LL x , LL t) {
    LL Ret = 0 , xx = x , yy = 1 , p = 1 ;
    while ( t > 0 ) {
        if ( t & 1 ) {
            Ret += yy * p ;
            p *= xx ;
        }
        t >>= 1 ;
        yy = yy * xx + yy ;
        xx = xx * xx ;
    }
    return Ret ;
}
void Init() {
    cin >> S ; totS = -1 ;
    SaveHashS.clear() ;
    for ( int i = 0 ; i < S.size() ; i ++ ) {
        int l = i , r = i ; LL cnt = 1LL ;
        if ( S[i] == '(' ) {
            l = i+1 ; r = l ;
            while ( S[r] != ')' ) r ++ ;
            r -- ;
            int tmp = r+2 ; cnt = 0LL ;
            while ( '0' <= S[tmp] && S[tmp] <= '9' ) {
                cnt = cnt * 10LL + (LL)(S[tmp] - '0') ;
                tmp ++ ;
            }
            i = tmp - 1 ;
        }
        lenS[++totS] = r - l + 1 ;
        LL hs = 0LL ;
        for ( int j = 0 ; j < lenS[totS] ; j ++ ) {
            hs = hs * P + (LL)(S[l+j] - 'a') ;
            A[totS][j] = hs ;
        }
        hs = 0LL ;
        for ( int j = lenS[totS]-1 ; j >= 0 ; j -- ) {
            hs += (LL)(S[l+j] - 'a') * Power(P , lenS[totS]-j-1) ;
            B[totS][j] = hs ;
        }
        cntS[totS] = cnt ;
    }
    totS ++ ;
    for ( int i = 0 ; i < totS ; i ++ ) PowerPS[i] = Power(P , lenS[i]) ;
    for ( int i = 0 ; i < totS ; i ++ ) PowerPSS[i] = Power(P , lenS[i] * cntS[i]) ;
    for ( int i = 0 ; i < totS ; i ++ ) PowerSumPS[i] = PowerSum( Power(P , lenS[i]) , cntS[i] ) ;
    for ( int i = 0 ; i < totS ; i ++ ) {
        STlenS[i][0] = lenS[i] * cntS[i] ;
        STPowerPSS[i][0] = PowerPSS[i] ;
        SThashS[i][0] = A[i][lenS[i]-1] * PowerSumPS[i] ;
    }
    for ( int j = 1 ; (1<<j) <= totS ; j ++ ) {
        for ( int i = 0 ; i < totS && i + (1<<(j-1)) < totS ; i ++ ) {
            STlenS[i][j] = STlenS[i][j-1] + STlenS[i+(1<<(j-1))][j-1] ;
            STPowerPSS[i][j] = STPowerPSS[i][j-1] * STPowerPSS[i+(1<<(j-1))][j-1] ;
            SThashS[i][j] = SThashS[i][j-1] * STPowerPSS[i+(1<<(j-1))][j-1] + SThashS[i+(1<<(j-1))][j-1] ;
        }
    }
}
void ReadPattern() {
    sumlenT = 0 ;
    cin >> T ; totT = -1 ; SaveT.clear() ;
    for ( int i = 0 ; i < T.size() ; i ++ ) {
        int l = i , r = i , cnt = 1LL ;
        if ( T[i] == '(' ) {
            l = i+1 ; r = l ;
            while ( T[r] != ')' ) r ++ ;
            r -- ;
            int tmp = r+2 ; cnt = 0LL ;
            while ( '0' <= T[tmp] && T[tmp] <= '9' ) {
                cnt = cnt * 10LL + (LL)(T[tmp] - '0') ;
                tmp ++ ;
            }
            i = tmp - 1 ;
        }
        lenT[++totT] = r - l + 1 ;
        sumlenT += (LL)cnt * (LL)(r - l + 1) ;
        string tmpT = "" ;
        for ( int j = 0 ; j < lenT[totT] ; j ++ ) tmpT += T[l+j] ;
        SaveT.push_back(tmpT) ;
        LL hs = 0LL ;
        for ( int j = 0 ; j < lenT[totT] ; j ++ ) {
            hs = hs * P + (LL)(T[l+j] - 'a') ;
            C[totT][j] = hs ;
        }
        hs = 0LL ;
        for ( int j = lenT[totT]-1 ; j >= 0 ; j -- ) {
            hs += (LL)(T[l+j] - 'a') * Power(P , lenT[totT]-j-1) ;
            D[totT][j] = hs ;
        }
        cntT[totT] = cnt ;
    }
    totT ++ ;
    for ( int i = 0 ; i < totT ; i ++ ) PowerPT[i] = Power(P , lenT[i]) ;
    for ( int i = 0 ; i < totT ; i ++ ) PowerPTT[i] = Power(P , lenT[i] * cntT[i]) ;
    for ( int i = 0 ; i < totT ; i ++ ) PowerSumPT[i] = PowerSum( Power(P , lenT[i]) , cntT[i] ) ;
    for ( int i = 0 ; i < totT ; i ++ ) {
        STlenT[i][0] = lenT[i] * cntT[i] ;
        STPowerPTT[i][0] = PowerPTT[i] ;
        SThashT[i][0] = C[i][lenT[i]-1] * PowerSumPT[i] ;
    }
    for ( int j = 1 ; (1<<j) <= totT ; j ++ ) {
        for ( int i = 0 ; i < totT ; i ++ ) {
            STlenT[i][j] = STlenT[i][j-1] + STlenT[(i+(1<<(j-1)))%totT][j-1] ;
            STPowerPTT[i][j] = STPowerPTT[i][j-1] * STPowerPTT[(i+(1<<(j-1)))%totT][j-1] ;
            SThashT[i][j] = SThashT[i][j-1] * STPowerPTT[(i+(1<<(j-1)))%totT][j-1] + SThashT[(i+(1<<(j-1)))%totT][j-1] ;
        }
    }
}

LL HashS( LL _Len ) {
    if ( SaveHashS.find(_Len) != SaveHashS.end() ) return SaveHashS[_Len] ;
    LL Len = _Len , Ret = 0 ;
    int i = 0 , j = 0 ; while ( (1<<j) <= totS ) j ++ ;
    for ( j -- ; j >= 0 ; j -- )
        if ( i + (1<<j) < totS && STlenS[i][j] < Len ) {
            Len -= STlenS[i][j] ;
            Ret = Ret * STPowerPSS[i][j] + SThashS[i][j] ;
            i += (1<<j) ;
        }
    LL tmp = Len / lenS[i] ;
    Len -= lenS[i] * tmp ;
    Ret = Ret * Power(P , lenS[i] * tmp) + A[i][lenS[i]-1] * PowerSum( PowerPS[i] , tmp ) ;
    if ( Len > 0 ) {
        Ret = Ret * Power(P , Len) + A[i][Len-1] ;
        Len = 0 ;
    }
    SaveHashS[_Len] = Ret ;
    return Ret ;
}
LL HashT( int _i , int _j , LL _k , LL _Len ) { // i-th block of T, from the j-th character, with k more repetation
    int i = _i , j = _j ; LL k = _k ;
    LL Len = _Len ;
    LL Ret = 0 ;
    if ( Len <= (lenT[i] - j) ) {
        while ( Len > 0 ) {
            Ret = Ret * P + (LL)(SaveT[i][j] - 'a') ;
            Len -- ;
            j ++ ;
        }
        return Ret ;
    } else {
        Ret = D[i][j] ;
        Len -= (lenT[i] - j) ;
    }
    if ( Len <= k*lenT[i] ) {
        LL tmp = Len / lenT[i] ;
        Ret = Ret * Power(P , tmp*lenT[i]) + C[i][lenT[i]-1] * PowerSum( PowerPT[i] , tmp ) ;
        Len -= tmp * lenT[i] ;
        if ( Len > 0 ) Ret = Ret * Power(P , Len) + C[i][Len-1] ;
        return Ret ;
    } else {
        Ret = Ret * Power(P , k*lenT[i]) + C[i][lenT[i]-1] * PowerSum( PowerPT[i] , k ) ;
        Len -= k*lenT[i] ;
    }
    j = i+1 ; int l = 0 ; while ( (1<<l) <= totT ) l ++ ;
    for ( l -- ; l >= 0 ; l -- )
        if ( j + (1<<l) <= totT + i && Len > STlenT[j%totT][l] ) {
            Len -= STlenT[j%totT][l] ;
            Ret = Ret * STPowerPTT[j%totT][l] + SThashT[j%totT][l] ;
            j += (1<<l) ;
        }
    int t = j%totT ;
    if ( t != i ) {
        LL tmp = Len / lenT[t] ;
        Ret = Ret * Power(P , lenT[t] * tmp) + C[t][lenT[t]-1] * PowerSum( PowerPT[t] , tmp ) ;
        Len -= tmp * lenT[t] ;
        if ( Len > 0 ) Ret = Ret * Power(P , Len) + C[t][Len-1] ;
        return Ret ;
    }
    LL tmp = Len / lenT[i] ;
    Ret = Ret * Power(P , tmp*lenT[i]) + C[i][lenT[i]-1] * PowerSum( Power(P,lenT[i]) , tmp ) ;
    Len -= tmp * lenT[i] ;
    if ( Len > 0 ) Ret = Ret * Power(P , Len) + C[i][Len-1] ;
    return Ret ;
}
LL TRY( int i , int j , LL k ) {
    LL L = 0 , R = sumlenT , Mid ;
    while ( L < R ) {
        Mid = (L + R + 1) / 2 ;
        if ( HashS( Mid ) == HashT( i , j , k , Mid ) ) L = Mid ;
        else                                            R = Mid-1 ;
    }
    return L ;
}
bool Solve() {
    for ( int i = 0 ; i < totT ; i ++ ) {
        int len = lenT[i] , cnt = cntT[i] ;
        for ( int j = 0 ; j < len ; j ++ ) {
            if ( S[0] == '(' ) { if ( SaveT[i][j] != S[1] ) continue ; }
            else               { if ( SaveT[i][j] != S[0] ) continue ; }
            if ( cnt == 1 ) {
                if ( sumlenT == TRY(i , j , 0) ) return true ;
            } else {
                LL L = 0 , R = cnt-1 , Mid ;
                while ( L+1 < R ) {
                    Mid = (L+R) / 2 ;
                    LL tmp = TRY(i , j , Mid) ;
                    if ( HashS(tmp) == HashT(i , j , Mid+1 , tmp) && (tmp == sumlenT || HashS(tmp+1) != HashT(i , j , Mid+1 , tmp+1)) ) R = Mid ;
                    else                                                                                                                L = Mid ;
                }
                if ( sumlenT == TRY(i , j , R) ) return true ;
            }
        }
    }
    return false ;
}
int main() {
    freopen("A.in" , "r" , stdin) ;
    freopen("A.out", "w" ,stdout) ;
    int Test ; cin >> Test ;
    for ( int i = 1 ; i <= Test ; i ++ ) {
        Init() ;
        LL ans = 0 ;
        cin >> K ;
        for ( int j = 1 ; j <= K ; j ++ ) {
            ReadPattern() ;
            if ( Solve() ) ans += (LL)j * j ;
        }
        cout << "Case #" << i << ": " << ans << "\n" ;
    }
	fprintf(stderr,"%.2f s\n",clock()*1.0/CLOCKS_PER_SEC);
	for(;;);
}
