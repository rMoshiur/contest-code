#include <iostream>
#include <sstream>
#include <cstring>
#include <cstdio>
#include <algorithm>
#include <map>
#include <cassert>
#include <utility>
#include <random>
#include <queue>
#include <ctime>

using namespace std;

int n, m;
vector<pair<int, int> > adj[600000];
long long ds[600000], dt[600000];

void sssp(long long d[], int s) {
    priority_queue<pair<long long, int> > q;
    fill(d, d + n + m, numeric_limits<long long>::max());
    q.push(make_pair(-(d[s] = 0), s));
    while (q.size()) {
        if (q.top().first == -d[q.top().second]) {
            int u = q.top().second;
            for (auto v:adj[u]) {
                if (d[v.first] > d[u] + v.second) {
                    q.push(make_pair(-(d[v.first] = d[u] + v.second), v.first));
                }
            }
        }
        q.pop();
    }
}

void solve() {
    scanf("%d%d", &n, &m);
    for (int i = 0; i < n + m; i++) {
        adj[i].clear();
    }
    for (int i = 0; i < m; i++) {
        int w, s;
        scanf("%d%d", &w, &s);
        for (int j = 0; j < s; j++) {
            int v;
            scanf("%d", &v);
            v--;
            adj[v].push_back(make_pair(n + i, w));
            adj[n + i].push_back(make_pair(v, w));
        }
    }
    sssp(ds, 0);
    sssp(dt, n - 1);
    long long ans = numeric_limits<long long>::max();
    vector<int> ansu;
    for (int i = 0; i < n; i++) {
        if (max(ds[i], dt[i]) < ans) {
            ans = max(ds[i], dt[i]);
            ansu.clear();
        }
        if (max(ds[i], dt[i]) == ans) {
            ansu.push_back(i);
        }
    }
    if (ans == numeric_limits<long long>::max()) {
        cout << "Evil John" << endl;
    } else {
        cout << ans / 2 << endl;
        for (int i = 0; i < ansu.size(); i++) {
            cout << 1 + ansu[i] << char(i + 1 == ansu.size() ? '\n' : ' ');
        }
    }
}

int main() {
    freopen("M.in","r",stdin);
    freopen("M.out","w",stdout);
    int T;
    scanf("%d", &T);
    for (int _ = 1 ; _ <= T ; _ ++ ) {
        cout << "Case #" << _ << ": " ;
        solve();
    }
    fprintf(stderr, "Used: %fs\n", (double) clock() / CLOCKS_PER_SEC);
    for (;;) ;
    return 0;
}
