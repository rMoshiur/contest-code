#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include <unordered_map>
#include <ctime>
using namespace std;
const int MAXN = 1050;
const int MAXO = 1050;
const int MAXL = 1050;
//                 U   R  D  L
const int dx[4] = {-1, 0, 1, 0};
const int dy[4] = {0, 1, 0, -1};

int n, m, o, l;
char comm[MAXL];
bool bad[MAXN][MAXN];
int ansx[MAXN][MAXN], ansy[MAXN][MAXN];
int obsx[MAXO + MAXN], obsy[MAXO + MAXN];

int encode(int x, int y)
{
	return (x - 1) * m + y;
}
struct pairhash
{
  size_t operator()(const pair<int, int> &x) const
  {
    return (x.first + 10000) * 10000 + x.second;
  }
};
unordered_map<pair<int, int>, int, pairhash> pos2set;
int getSet(int x, int y)
{
	return pos2set[make_pair(x, y)];
}
void setSet(int x, int y, int v)
{
	pos2set[make_pair(x, y)] = v;
}
int fa[MAXN * MAXN];
int Father(int x)
{
	if (x == fa[x]) return x;
	return fa[x] = Father(fa[x]);
}
pair<int, int> set2pos[MAXN * MAXN];
int main()
{
    freopen("H.in" , "r" , stdin) ;
//    freopen("H.out", "w" ,stdout) ;
    
	int cases;
	scanf("%d", &cases);
	for (int tcase = 1; tcase <= cases; ++tcase)
	{
		scanf("%d%d%d%d", &n, &m, &o, &l);
		for (int i = 0; i <= n + 1; ++i)
			for (int j = 0; j <= m + 1; ++j)
				bad[i][j] = i == 0 || i == n + 1 || j == 0 || j == m + 1;
		for (int i = 0; i < o; ++i)
		{
			int x, y;
			scanf("%d%d", &x, &y);
			bad[x][y] = true;
			obsx[i] = x; obsy[i] = y;
		}
		scanf("%s", comm);
		for (int i = 0 ; i < l; ++i)
		{
			if (comm[i] == 'U') comm[i] = 0;
			if (comm[i] == 'R') comm[i] = 1;
			if (comm[i] == 'D') comm[i] = 2;
			if (comm[i] == 'L') comm[i] = 3;
		}
		pos2set.clear();
		for (int i = 1; i <= n; ++i)
			for (int j = 1; j <= m; ++j)
				if (!bad[i][j])
				{
					fa[encode(i, j)] = encode(i, j);
					setSet(i, j, encode(i, j));
				}
	
		int totx = 0, toty = 0;
		for (int k = 0; k < l; ++k)
		{
			int num_o = o;
			if (comm[k] == 0)
				for (int i = 1; i <= m; ++i, ++num_o)
					obsx[num_o] = 0, obsy[num_o] = i;
			if (comm[k] == 2)
				for (int i = 1; i <= m; ++i, ++num_o)
					obsx[num_o] = n + 1, obsy[num_o] = i;
			if (comm[k] == 1)
				for (int i = 1; i <= n; ++i, ++num_o)
					obsx[num_o] = i, obsy[num_o] = m + 1;
			if (comm[k] == 3)
				for (int i = 1; i <= n; ++i, ++num_o)
					obsx[num_o] = i, obsy[num_o] = 0;
			for (int i = 0; i < num_o; ++i)
			{
				int x0 = obsx[i] - dx[comm[k]], y0 = obsy[i] - dy[comm[k]];
				if (bad[x0][y0])
					continue;
				int s = getSet(x0 - totx, y0 - toty);
				if (s == 0)
					continue;
				int x1 = x0 - dx[comm[k]], y1 = y0 - dy[comm[k]];
				if (!bad[x1][y1])
				{
					fa[getSet(x1 - totx, y1 - toty)] = s;
					setSet(x1 - totx, y1 - toty, 0);
				}
				setSet(x0 - totx, y0 - toty, 0);
				setSet(x0 - totx - dx[comm[k]], y0 - toty - dy[comm[k]], s);
			}			

			totx += dx[comm[k]]; toty += dy[comm[k]];
		}
		for (auto p : pos2set)
			set2pos[p.second] = p.first;
		for (int i = 1; i <= n; ++i)
			for (int j = 1; j <= m; ++j)
			{
				pair<int, int> pos = set2pos[Father(encode(i, j))];
				ansx[i][j] = pos.first + totx;
				ansy[i][j] = pos.second + toty;
			}
		long long outans = 0 ;
		for (int i = 1; i <= n; ++i)
			for (int j = 1; j <= m; ++j)
				if (!bad[i][j]) {
                    outans += (long long)(i - ansx[i][j])*(long long)(i - ansx[i][j]) + (long long)(j - ansy[i][j])*(long long)(j - ansy[i][j]) ;
					//printf("%d %d\n", ansx[i][j], ansy[i][j]);
                }
        printf("Case #%d: %I64d\n" , tcase, outans) ;
	}
	fprintf(stderr,"%.2f s\n",clock()*1.0/CLOCKS_PER_SEC);
	for(;;);
	return 0;
}
