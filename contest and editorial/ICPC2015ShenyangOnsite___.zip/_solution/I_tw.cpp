#include<bits/stdc++.h>
#include<ctime>
using namespace std;
long long p1[100000+10],p2[1000+10][1000+10];
long long c1[100000+10],c2[1000+10][1000+10];
int maxa[1000+10][1000+10];
int a,b,c,d,e;

int main(){
    freopen("I.in" , "r" , stdin) ;
    freopen("I.out", "w" ,stdout) ;
    
    int T,Case=0,n,m;
    scanf("%d",&T);
    while(T--){
        scanf("%d%d",&n,&m);
        memset(p1,-1,sizeof(p1));
        memset(c1,0,sizeof(c1));
        for(int i=0;i<n;i++){
            scanf("%d%d",&a,&b);
            if(a>p1[b])p1[b]=a,c1[b]=1;
            else if(a==p1[b])c1[b]++;
        }
        memset(p2,-1,sizeof(p2));
        for(int i=0;i<m;i++)
        {
            scanf("%d%d%d",&c,&d,&e);
            if(p2[c][d] < p1[e])
            {
                p2[c][d]=p1[e];
                c2[c][d]=c1[e];
            }else if(p2[c][d] == p1[e])
            {
                c2[c][d]+=c1[e];
            }
        }
        memset(maxa,-1,sizeof(maxa));
        long long ans=0;
        for(int i=1000;i>=0;i--)
        {
            for(int j=1000;j>=0;j--)
            {
                if(i==1000 && j==1000)
                {
                    if(p2[i][j]>0)ans=c2[i][j];
                    continue;
                }
                maxa[i][j]=max(maxa[i+1][j],maxa[i][j+1]);
                if(maxa[i][j]<p2[i][j])
                {
                    ans+=c2[i][j];
                    maxa[i][j]=p2[i][j];
                }
            }
        }
        cout<<"Case #"<<++Case<<": "<<ans<<endl;
    }
	fprintf(stderr,"%.2f s\n",clock()*1.0/CLOCKS_PER_SEC);
	for(;;);
    return 0;
}
